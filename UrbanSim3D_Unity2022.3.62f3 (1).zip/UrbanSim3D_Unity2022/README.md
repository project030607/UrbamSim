# UrbanSim 3D (Unity 2022.3.62f3)

Residential emergency-response training simulator: a 20-storey tower with two scenarios,
**Fire Emergency** (alarm, smoke, sprinklers, evacuation) and **Water Leakage** (report, plumber, hidden source, repair).

## Open and run
1. Install Unity **2022.3.62f3** (Windows). The project uses the **Built-in Render Pipeline** and only built-in modules plus `com.unity.test-framework`.
2. Unity Hub -> Add -> select the `UrbanSim3D_Unity2022` folder -> open with 2022.3.62f3.
3. Wait for the first import to finish. `MainMenu` opens automatically; press **Play**. (An editor script makes Play always start from `MainMenu`, whichever scene is open.)
4. Optional standalone build: menu **UrbanSim > Build Windows Standalone** (needs the Windows Build Support module). Or File > Build Settings (all 4 scenes are already listed, MainMenu first).

## Scenes
`MainMenu`, `BuildingEnvironment`, `FireEmergency`, `WaterLeakage` (Assets/Scenes). Each scene holds one `Bootstrap` object; the world (tower, interiors, stairs, surroundings, characters, effects, UI) is generated in code at load time. There are no prefabs or imported models.

## Controls
W/A/S/D move, mouse look, Shift run, mouse wheel zoom, **E** interact, **Esc** pause, **Tab** frees the cursor so the on-screen buttons (Interact, Pause, Restart, Menu, sim speed) can be clicked.
Lifts: look at the dark panel beside a lift door and press E, then pick a floor. Stairs: walkable stair cores at both ends of every floor.

## Fire scenario
Briefing -> choose fire location (apartment / corridor / random) -> Start Scenario -> 6 s normal -> fire + alarm -> sprinklers after 7 s (flames fall, smoke persists, red floor = unsafe) -> evacuation of 24 residents by stairs (they pick the stair that avoids the hazard) -> results (residents total/out/remaining, time, hazard exposure, route-safety label). Restart reloads the scene.

## Leak scenario
Briefing -> Start -> report the leak (talk to the resident or press **Report Water Leakage**) -> plumber walks in, rides the lift, walks to the apartment -> inspect the puddle / sink / heater (wrong ones are counted) -> open the wall access panel (source found) -> close the red valve -> repair the joint (3 s, plumber must be on site) -> leak particles and spreading puddle stop -> results (time to investigate, time to repair, status, located, stopped). The apartment is random each run.

## History and analytics
Every finished or ended run is written to `urbansim_history.json` in `Application.persistentDataPath` and shown in the menu (History, Analytics). Nothing is hard-coded.

## What was actually verified (read this)
Done in the build environment (no Unity Editor was available there):
- The pure logic (`FireModel`, `LeakModel`, analytics, layout/stair waypoints): compiled with Mono and run through 47 assertions, all passed.
- All runtime C# files compile with Mono's `mcs` against a hand-written UnityEngine stub. That catches syntax/type errors in this code only; it does not validate real Unity API behaviour.
- Package contents: ZIP integrity, scene/script GUID consistency, build-settings references.

**NOT done: opening the project in Unity 2022.3.62f3, import, Play mode, visual check, frame-rate measurement, standalone build, or running the NUnit tests in Assets/Tests (Window > General > Test Runner > EditMode).** Expect that first-run Unity may show errors or look wrong somewhere that this environment could not detect.

## Known limitations
- Characters are primitive-shape people with procedural walk cycles; no skinned models.
- Fire/smoke are particle approximations, not physics.
- Textures are small procedural ones; windows are opaque dark glass; balconies are decorative.
- Lighting is flat ambient + one sun + a small headlamp on the player (no baked lighting) to keep Intel Iris Xe load low. Performance is unmeasured.
- Input uses the legacy Input Manager (default for this project). `ProjectSettings` contains only `ProjectVersion.txt` and `EditorBuildSettings.asset`; Unity regenerates the rest with defaults.
- Resident count is fixed at 24; fire floor range is 2-15.
