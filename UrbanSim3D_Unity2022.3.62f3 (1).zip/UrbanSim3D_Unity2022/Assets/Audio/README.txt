Audio clips (alarm.wav, spray.wav) are generated synthetic tones/noise and live in Assets/Resources/Audio so they can be loaded by name.
