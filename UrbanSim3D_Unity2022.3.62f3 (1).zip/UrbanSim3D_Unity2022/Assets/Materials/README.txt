Materials and textures are generated at runtime from the shared Resources/UrbanSim/BaseStandard.mat (Standard shader). See Procedural.cs.
