using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace UrbanSim.Editor
{
    /// <summary>Makes Play always start from MainMenu, opens it on first load and applies project defaults.</summary>
    [InitializeOnLoad]
    public static class UrbanSimEditorSetup
    {
        const string MenuScene = "Assets/Scenes/MainMenu.unity";

        static UrbanSimEditorSetup()
        {
            EditorApplication.delayCall += Setup;
        }

        static void Setup()
        {
            var scene = AssetDatabase.LoadAssetAtPath<SceneAsset>(MenuScene);
            if (scene == null) return;
            EditorSceneManager.playModeStartScene = scene;
            if (PlayerSettings.productName != "UrbanSim 3D") PlayerSettings.productName = "UrbanSim 3D";
            if (PlayerSettings.companyName != "UrbanSim") PlayerSettings.companyName = "UrbanSim";
            if (!EditorApplication.isPlayingOrWillChangePlaymode
                && string.IsNullOrEmpty(EditorSceneManager.GetActiveScene().path)
                && !EditorSceneManager.GetActiveScene().isDirty)
            {
                EditorSceneManager.OpenScene(MenuScene, OpenSceneMode.Single);
            }
        }
    }

    public static class UrbanSimBuild
    {
        [MenuItem("UrbanSim/Build Windows Standalone")]
        public static void BuildWindows()
        {
            string[] scenes = EditorBuildSettings.scenes.Where(s => s.enabled).Select(s => s.path).ToArray();
            var opts = new BuildPlayerOptions
            {
                scenes = scenes,
                locationPathName = "Builds/UrbanSim3D/UrbanSim3D.exe",
                target = BuildTarget.StandaloneWindows64,
                options = BuildOptions.None
            };
            var report = BuildPipeline.BuildPlayer(opts);
            Debug.Log("UrbanSim build result: " + report.summary.result);
        }

        [MenuItem("UrbanSim/Open Main Menu Scene")]
        public static void OpenMenu()
        {
            EditorSceneManager.OpenScene("Assets/Scenes/MainMenu.unity", OpenSceneMode.Single);
        }
    }
}
