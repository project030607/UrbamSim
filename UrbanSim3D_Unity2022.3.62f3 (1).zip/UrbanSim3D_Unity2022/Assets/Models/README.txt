No imported 3D models are used. The tower, interiors, vehicles, trees and characters are generated procedurally at load time by Scripts/Runtime/BuildingBuilder.cs and Procedural.cs.
