using System.Collections.Generic;
using System.IO;
using NUnit.Framework;
using UnityEngine;

namespace UrbanSim.Tests
{
    public class FireModelTests
    {
        static void Run(FireModel m, float seconds) { for (float t = 0f; t < seconds; t += 0.1f) m.Tick(0.1f); }

        [Test] public void Timeline_IgnitesAlarmsSprinklesEvacuates()
        {
            var m = new FireModel(); m.Configure(7, 1, false); m.Begin(24);
            Assert.AreEqual(FirePhase.Normal, m.Phase);
            Run(m, 6.3f); Assert.IsTrue(m.AlarmOn);
            Run(m, 7.2f); Assert.IsTrue(m.SprinklersActive);
            Run(m, 3.0f); Assert.AreEqual(FirePhase.Evacuation, m.Phase);
        }

        [Test] public void Sprinklers_SuppressFlames_ButSmokePersists()
        {
            var m = new FireModel(); m.Configure(7, 1, false); m.Begin(24);
            Run(m, 50f);
            Assert.Less(m.FireIntensity, 0.3f);
            Assert.Greater(m.SmokeLevel, 0.8f);
            Assert.IsTrue(m.HazardActive);
        }

        [Test] public void Completes_WhenAllEvacuated()
        {
            var m = new FireModel(); m.Begin(3);
            m.ReportEvacuated(); m.ReportEvacuated();
            Assert.AreNotEqual(FirePhase.Complete, m.Phase);
            m.ReportEvacuated();
            Assert.AreEqual(FirePhase.Complete, m.Phase);
            Assert.AreEqual(0, m.Remaining);
        }

        [Test] public void Reset_RestoresInitialState()
        {
            var m = new FireModel(); m.Begin(5); Run(m, 30f); m.ReportEvacuated();
            m.Reset();
            Assert.AreEqual(FirePhase.Briefing, m.Phase);
            Assert.AreEqual(0, m.Evacuated);
            Assert.AreEqual(0f, m.FireIntensity); Assert.AreEqual(0f, m.SmokeLevel);
            Assert.IsFalse(m.AlarmOn); Assert.IsFalse(m.SprinklersActive);
        }

        [Test] public void Timeout_EndsIncomplete()
        {
            var m = new FireModel(); m.Begin(3); m.TimeLimit = 20f; Run(m, 21f);
            Assert.AreEqual(FirePhase.Complete, m.Phase); Assert.IsTrue(m.TimedOut);
            Assert.IsFalse(m.BuildRecord().completed);
        }

        [Test] public void Routing_AvoidsFire()
        {
            var m = new FireModel(); m.Configure(7, 0, false); m.Begin(5);
            Assert.AreEqual(1, m.ChooseRoute(10, 3).Core);
            Assert.AreEqual(1, m.ChooseRoute(7, 1).Core);
            Assert.AreEqual(0, m.ChooseRoute(2, 0).Core);
        }
    }

    public class LeakModelTests
    {
        [Test] public void Sequence_RequiresLocateValvePlumber()
        {
            var l = new LeakModel();
            Assert.AreEqual(InspectOutcome.NotReady, l.Inspect(LeakModel.PointPanel));
            Assert.IsTrue(l.Report());
            l.Tick(10f);
            Assert.AreEqual(RepairOutcome.NotLocated, l.TryRepair());
            Assert.AreEqual(InspectOutcome.Wrong, l.Inspect(LeakModel.PointSink));
            Assert.AreEqual(1, l.WrongInspections);
            Assert.AreEqual(InspectOutcome.SourceFound, l.Inspect(LeakModel.PointPanel));
            Assert.AreEqual(10f, l.TimeToInvestigate, 0.01f);
            Assert.AreEqual(RepairOutcome.NeedPlumber, l.TryRepair());
            l.PlumberArrived();
            Assert.AreEqual(RepairOutcome.NeedValveClosed, l.TryRepair());
            Assert.IsTrue(l.CloseValve());
            l.Tick(5f);
            Assert.AreEqual(RepairOutcome.Repaired, l.TryRepair());
            Assert.AreEqual(0f, l.LeakRate);
            Assert.AreEqual(5f, l.TimeToRepair, 0.01f);
        }

        [Test] public void Reset_ClearsEverything()
        {
            var l = new LeakModel(); l.Report(); l.Tick(3f); l.PlumberArrived(); l.Inspect(LeakModel.PointSink);
            l.Reset();
            Assert.AreEqual(LeakPhase.Initial, l.Phase);
            Assert.IsFalse(l.PlumberOnSite); Assert.AreEqual(0, l.WrongInspections); Assert.AreEqual(0f, l.SpilledLitres);
        }

        [Test] public void Timeout_Fails()
        {
            var l = new LeakModel(); l.TimeLimit = 30f; l.Report(); l.Tick(31f);
            Assert.AreEqual(LeakPhase.Failed, l.Phase);
        }
    }

    public class PersistenceTests
    {
        [Test] public void History_RoundTripsAndFeedsAnalytics()
        {
            string path = Path.Combine(Path.GetTempPath(), "urbansim_test_" + System.Guid.NewGuid().ToString("N") + ".json");
            SaveSystem.PathOverride = path;
            try
            {
                SaveSystem.Append(new TrainingRecord { scenario = "Fire", totalResidents = 10, evacuated = 10, completed = true, durationSeconds = 100f });
                SaveSystem.Append(new TrainingRecord { scenario = "Leak", leakLocated = true, leakStopped = true, timeToInvestigate = 20f, timeToRepair = 10f });
                var h = SaveSystem.Load();
                Assert.AreEqual(2, h.records.Count);
                var a = AnalyticsSummary.From(h.records);
                Assert.AreEqual(1, a.FireRuns); Assert.AreEqual(1, a.LeakRepaired);
                Assert.AreEqual(100f, a.FireAvgEvacPercent, 0.01f);
                Assert.AreEqual(20f, a.LeakAvgInvestigate, 0.01f);
                SaveSystem.Clear();
                Assert.AreEqual(0, SaveSystem.Load().records.Count);
            }
            finally { SaveSystem.PathOverride = null; if (File.Exists(path)) File.Delete(path); }
        }
    }

    public class LayoutTests
    {
        [Test] public void StairDescent_SpansOneFloor()
        {
            var p = Layout.StairDescent(0, 5);
            Assert.AreEqual(Layout.FloorY(5), p[0].y, 0.001f);
            Assert.AreEqual(Layout.FloorY(4), p[p.Count - 1].y, 0.001f);
        }
    }
}
