No prefab assets are used. All objects are created from code at scene load, so scenes contain no fragile inspector references.
