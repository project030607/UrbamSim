The interface is drawn with Unity IMGUI (Scripts/UI). No UI package or UI assets are required.
