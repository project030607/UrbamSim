using UnityEngine;

namespace UrbanSim
{
    /// <summary>
    /// Every scene contains one GameObject with this component. It builds the whole world procedurally at load,
    /// so scenes have no fragile inspector references.  sceneKind: 0 MainMenu, 1 BuildingEnvironment, 2 FireEmergency, 3 WaterLeakage.
    /// </summary>
    public class SceneBootstrap : MonoBehaviour
    {
        public int sceneKind;

        void Awake()
        {
            GameState.ResetForScene();
            Application.targetFrameRate = 60;
            QualitySettings.shadowDistance = sceneKind == 0 ? 160f : 70f;
            QualitySettings.shadowCascades = 2;
            QualitySettings.pixelLightCount = 2;
            QualitySettings.antiAliasing = 0;

            // remove any stray cameras / listeners from the scene file so there is exactly one of each
            foreach (Camera c in FindObjectsOfType<Camera>()) Destroy(c.gameObject);
            foreach (AudioListener a in FindObjectsOfType<AudioListener>()) Destroy(a);

            SetupLighting();

            switch (sceneKind)
            {
                case 0: BuildMenu(); break;
                case 1: BuildExplore(); break;
                case 2: BuildFire(); break;
                default: BuildLeak(); break;
            }
        }

        void SetupLighting()
        {
            var sun = new GameObject("Sun").AddComponent<Light>();
            sun.type = LightType.Directional;
            sun.transform.rotation = Quaternion.Euler(52f, -35f, 0f);
            sun.intensity = 1.05f;
            sun.color = new Color(1f, 0.96f, 0.9f);
            sun.shadows = LightShadows.Soft;
            sun.shadowStrength = 0.75f;
            RenderSettings.sun = sun;
            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
            RenderSettings.ambientLight = new Color(0.58f, 0.6f, 0.66f);
            RenderSettings.fog = true;
            RenderSettings.fogMode = FogMode.Linear;
            RenderSettings.fogColor = new Color(0.72f, 0.82f, 0.92f);
            RenderSettings.fogStartDistance = 160f;
            RenderSettings.fogEndDistance = 420f;
        }

        void BuildMenu()
        {
            BuildingBuilder.Build(false);
            var cam = new GameObject("MenuCamera").AddComponent<Camera>();
            cam.gameObject.tag = "MainCamera";
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(0.62f, 0.78f, 0.95f);
            cam.fieldOfView = 42f; cam.farClipPlane = 700f;
            cam.gameObject.AddComponent<AudioListener>();
            cam.gameObject.AddComponent<OrbitCamera>();
            Cursor.lockState = CursorLockMode.None; Cursor.visible = true;
            new GameObject("Menu").AddComponent<MenuController>();
        }

        PlayerController MakePlayer(BuildingBuilder b)
        {
            var player = PlayerController.Create(new Vector3(12f, 0.1f, -8f), 0f);
            var hud = new GameObject("HUD").AddComponent<HudController>();
            hud.Init(player);
            return player;
        }

        void BuildExplore()
        {
            var b = BuildingBuilder.Build(true);
            var p = MakePlayer(b);
            HudController.Instance.ModeTitle = "Explore the Building";
            HudController.Instance.Toast("Walk into the lobby. Use the lift panel (E) or the stair cores to reach any of the 20 floors.", 7f);
        }

        void BuildFire()
        {
            var b = BuildingBuilder.Build(true);
            var p = MakePlayer(b);
            new GameObject("FireScenario").AddComponent<FireScenario>().Init(b, p, HudController.Instance);
        }

        void BuildLeak()
        {
            var b = BuildingBuilder.Build(true);
            var p = MakePlayer(b);
            new GameObject("LeakScenario").AddComponent<LeakScenario>().Init(b, p, HudController.Instance);
        }
    }

    /// <summary>Slow orbit around the tower for the menu background.</summary>
    public class OrbitCamera : MonoBehaviour
    {
        float angle = 200f;
        void Update()
        {
            angle += Time.deltaTime * 6f;
            float r = 95f;
            Vector3 center = new Vector3(12f, 30f, 6f);
            float rad = angle * Mathf.Deg2Rad;
            transform.position = new Vector3(center.x + Mathf.Sin(rad) * r, 34f, center.z + Mathf.Cos(rad) * r);
            transform.LookAt(center);
        }
    }
}
