using UnityEngine;

namespace UrbanSim
{
    /// <summary>Loads generated audio from Resources/Audio and creates simple audio sources.</summary>
    public static class AudioLib
    {
        public static AudioClip Clip(string name)
        {
            return Resources.Load<AudioClip>("Audio/" + name);
        }

        public static AudioSource Make(Transform parent, string clipName, bool loop, float volume, float spatialBlend)
        {
            var go = new GameObject("Audio_" + clipName);
            go.transform.SetParent(parent, false);
            var src = go.AddComponent<AudioSource>();
            src.clip = Clip(clipName);
            src.loop = loop;
            src.volume = volume;
            src.spatialBlend = spatialBlend;
            src.playOnAwake = false;
            src.rolloffMode = AudioRolloffMode.Linear;
            src.minDistance = 3f;
            src.maxDistance = 45f;
            return src;
        }

        public static void Play(AudioSource s)
        {
            if (s != null && s.clip != null && !s.isPlaying) s.Play();
        }

        public static void Stop(AudioSource s)
        {
            if (s != null && s.isPlaying) s.Stop();
        }
    }
}
