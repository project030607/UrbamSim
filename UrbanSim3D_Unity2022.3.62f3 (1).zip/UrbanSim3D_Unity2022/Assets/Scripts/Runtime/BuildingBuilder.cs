using System;
using System.Collections.Generic;
using UnityEngine;

namespace UrbanSim
{
    /// <summary>Generates the 20-storey tower, its two stair cores, interiors and the surroundings at runtime.</summary>
    public class BuildingBuilder
    {
        public Transform Root;
        public Transform ScenarioRoot;
        readonly bool interior;
        const float T = 0.25f;     // wall thickness
        const float H = Layout.FloorHeight;

        BuildingBuilder(bool withInterior) { interior = withInterior; }

        public static BuildingBuilder Build(bool withInterior)
        {
            var b = new BuildingBuilder(withInterior);
            b.Root = new GameObject("UrbanSimTower").transform;
            b.ScenarioRoot = new GameObject("ScenarioObjects").transform;
            var tower = new GameObject("Tower").transform;
            tower.SetParent(b.Root, false);
            for (int f = 0; f < Layout.Floors; f++) b.BuildFloor(tower, f);
            b.BuildCore(tower, 0);
            b.BuildCore(tower, 1);
            b.BuildRoof(tower);
            b.BatchStatic(tower);

            var env = new GameObject("Surroundings").transform;
            env.SetParent(b.Root, false);
            b.BuildSurroundings(env);
            b.BatchStatic(env);
            return b;
        }

        void BatchStatic(Transform t)
        {
            try
            {
                var list = new List<GameObject>();
                foreach (MeshFilter mf in t.GetComponentsInChildren<MeshFilter>())
                    if (mf.sharedMesh != null && mf.GetComponent<TextMesh>() == null) list.Add(mf.gameObject);
                StaticBatchingUtility.Combine(list.ToArray(), t.gameObject);
            }
            catch (Exception e) { Debug.LogWarning("UrbanSim: static batching skipped: " + e.Message); }
        }

        // ------------------------------------------------------------------ floors
        void BuildFloor(Transform parent, int f)
        {
            var fl = new GameObject("Floor_" + Layout.FloorName(f)).transform;
            fl.SetParent(parent, false);
            float y0 = Layout.FloorY(f);

            // slab
            if (f == 0)
                Procedural.Box(fl, "Slab", new Vector3(12f, 0f, 6f), new Vector3(24.3f, 0.04f, 12.3f), Procedural.Mat("floor"));
            else
                Procedural.Box(fl, "Slab", new Vector3(12f, y0 - 0.125f, 6f), new Vector3(24.5f, 0.25f, 12.5f), Procedural.Mat("floor"));

            BuildFacade(fl, f, true);
            BuildFacade(fl, f, false);
            if (f >= 1) BuildBalconies(fl, f);
            BuildEndWalls(fl, f);

            if (!interior) return;

            BuildCorridorWall(fl, f, 0);
            BuildCorridorWall(fl, f, 1);
            // apartment dividers
            for (int c = 1; c < Layout.AptCols; c++)
            {
                float x = c * Layout.AptWidth;
                if (f != 0) Procedural.Box(fl, "Divider_S" + c, new Vector3(x, y0 + H * 0.5f, 2.5f), new Vector3(0.2f, H, 5f), Procedural.Mat("wall"));
                Procedural.Box(fl, "Divider_N" + c, new Vector3(x, y0 + H * 0.5f, 9.5f), new Vector3(0.2f, H, 5f), Procedural.Mat("wall"));
            }
            // corridor lights
            for (int i = 0; i < 4; i++)
                Procedural.Box(fl, "CeilingLight", new Vector3(3f + i * 6f, y0 + H - 0.28f, 6f), new Vector3(1.2f, 0.04f, 0.5f), Procedural.Mat("light"), false);

            BuildApartmentFurniture(fl, f);
            BuildLiftAndSigns(fl, f);
            if (f == 0) BuildLobby(fl);
        }

        void BuildFacade(Transform parent, int f, bool south)
        {
            float y0 = Layout.FloorY(f);
            float z = south ? 0f : Layout.Depth;
            int block = Mathf.Clamp(f / 5, 0, 3);
            Material pier = Procedural.Mat("pier" + block);
            Material trim = Procedural.Mat("facade");
            Material glass = Procedural.Mat("glass");

            // segments: x0, x1, type (0 window, 1 opening)
            var segs = new List<float[]>();
            for (int c = 0; c < Layout.AptCols; c++)
            {
                segs.Add(new[] { c * 6f + 0.9f, c * 6f + 2.7f, 0f });
                segs.Add(new[] { c * 6f + 3.3f, c * 6f + 5.1f, 0f });
            }
            if (f == 0 && south)
            {
                segs.RemoveAll(s => s[1] > 9.4f && s[0] < 14.6f);
                segs.Add(new[] { 10.5f, 13.5f, 1f });
                segs.Sort((a, b) => a[0].CompareTo(b[0]));
            }

            float cursor = 0f;
            foreach (var s in segs)
            {
                if (s[0] - cursor > 0.01f) Pier(parent, y0, z, cursor, s[0], pier);
                if (s[2] < 0.5f)
                {
                    float w = s[1] - s[0], mx = (s[0] + s[1]) * 0.5f;
                    Procedural.Box(parent, "Sill", new Vector3(mx, y0 + 0.45f, z), new Vector3(w, 0.9f, T), trim);
                    Procedural.Box(parent, "Glass", new Vector3(mx, y0 + 1.55f, z), new Vector3(w, 1.3f, 0.06f), glass);
                    Procedural.Box(parent, "Header", new Vector3(mx, y0 + 2.7f, z), new Vector3(w, 1.0f, T), trim);
                }
                else
                {
                    float w = s[1] - s[0], mx = (s[0] + s[1]) * 0.5f;
                    Procedural.Box(parent, "EntranceHeader", new Vector3(mx, y0 + 2.9f, z), new Vector3(w, 0.6f, T), trim);
                }
                cursor = s[1];
            }
            if (Layout.Length - cursor > 0.01f) Pier(parent, y0, z, cursor, Layout.Length, pier);
        }

        void Pier(Transform parent, float y0, float z, float x0, float x1, Material m)
        {
            Procedural.Box(parent, "Pier", new Vector3((x0 + x1) * 0.5f, y0 + H * 0.5f, z), new Vector3(x1 - x0, H, T), m);
        }

        void BuildBalconies(Transform parent, int f)
        {
            float y0 = Layout.FloorY(f);
            Material slab = Procedural.Mat("concrete");
            Material rail = Procedural.Mat("railing");
            for (int c = 0; c < Layout.AptCols; c++)
            {
                float x = c * 6f + 3f;
                Procedural.Box(parent, "Balcony", new Vector3(x, y0 - 0.1f, -0.85f), new Vector3(3.4f, 0.2f, 1.5f), slab, false);
                Procedural.Box(parent, "BalconyRail", new Vector3(x, y0 + 0.45f, -1.58f), new Vector3(3.4f, 0.9f, 0.05f), rail, false);
                Procedural.Box(parent, "BalconyRailL", new Vector3(x - 1.68f, y0 + 0.45f, -0.85f), new Vector3(0.05f, 0.9f, 1.5f), rail, false);
                Procedural.Box(parent, "BalconyRailR", new Vector3(x + 1.68f, y0 + 0.45f, -0.85f), new Vector3(0.05f, 0.9f, 1.5f), rail, false);
            }
        }

        // short end walls with the emergency door to the stair core
        void BuildEndWalls(Transform parent, int f)
        {
            float y0 = Layout.FloorY(f);
            Material m = Procedural.Mat("facade");
            for (int core = 0; core < 2; core++)
            {
                float x = Layout.CoreX(core);
                Procedural.Box(parent, "EndWall", new Vector3(x, y0 + H * 0.5f, 2.7f), new Vector3(T, H, 5.4f), m);
                Procedural.Box(parent, "EndWall", new Vector3(x, y0 + H * 0.5f, 9.3f), new Vector3(T, H, 5.4f), m);
                Procedural.Box(parent, "EndHeader", new Vector3(x, y0 + 2.75f, 6f), new Vector3(T, 0.9f, 1.2f), m);
                if (interior)
                {
                    float sx = core == 0 ? 0.15f : x - 0.15f;
                    Procedural.Box(parent, "ExitSign", new Vector3(sx, y0 + 2.45f, 6f), new Vector3(0.05f, 0.22f, 0.6f), Procedural.Mat("exit"), false);
                }
            }
        }

        void BuildCorridorWall(Transform parent, int f, int side)
        {
            float y0 = Layout.FloorY(f);
            float z = side == 0 ? Layout.CorridorZ0 : Layout.CorridorZ1;
            Material wall = Procedural.Mat("wall");
            Material door = Procedural.Mat("door");
            if (f == 0 && side == 0)
            {
                // lobby opens onto the corridor
                Procedural.Box(parent, "LobbyWall", new Vector3(4.5f, y0 + H * 0.5f, z), new Vector3(9f, H, 0.2f), wall);
                Procedural.Box(parent, "LobbyWall", new Vector3(19.5f, y0 + H * 0.5f, z), new Vector3(9f, H, 0.2f), wall);
                Procedural.Box(parent, "LobbyHeader", new Vector3(12f, y0 + 2.9f, z), new Vector3(6f, 0.6f, 0.2f), wall);
                return;
            }
            float cursor = 0f;
            for (int c = 0; c < Layout.AptCols; c++)
            {
                float g0 = c * 6f + 2.5f, g1 = c * 6f + 3.5f;
                Procedural.Box(parent, "CorridorWall", new Vector3((cursor + g0) * 0.5f, y0 + H * 0.5f, z), new Vector3(g0 - cursor, H, 0.2f), wall);
                Procedural.Box(parent, "DoorHeader", new Vector3(c * 6f + 3f, y0 + 2.65f, z), new Vector3(1f, 1.1f, 0.2f), wall);
                // open door leaf hinged at g0, swung into the apartment
                float dz = side == 0 ? -0.45f : 0.45f;
                Procedural.Box(parent, "DoorLeaf", new Vector3(g0 + 0.03f, y0 + 1.03f, z + dz), new Vector3(0.05f, 2.05f, 0.9f), door, false);
                Procedural.Box(parent, "DoorPlate", new Vector3(g1 + 0.35f, y0 + 1.6f, side == 0 ? z + 0.11f : z - 0.11f), new Vector3(0.22f, 0.12f, 0.02f), Procedural.Mat("metal"), false);
                cursor = g1;
            }
            Procedural.Box(parent, "CorridorWall", new Vector3((cursor + Layout.Length) * 0.5f, y0 + H * 0.5f, z), new Vector3(Layout.Length - cursor, H, 0.2f), wall);
        }

        void BuildApartmentFurniture(Transform parent, int f)
        {
            float y0 = Layout.FloorY(f);
            for (int apt = 0; apt < 8; apt++)
            {
                if (!Layout.AptExists(f, apt)) continue;
                float x0 = Layout.AptCol(apt) * Layout.AptWidth;
                float zc = Layout.AptZ(apt);
                float zOuter = Layout.AptSide(apt) == 0 ? 1.2f : 10.8f;
                Procedural.Box(parent, "Sofa", new Vector3(x0 + 3.4f, y0 + 0.3f, zOuter), new Vector3(2.0f, 0.6f, 0.85f), Procedural.Mat((apt % 2 == 0) ? "fabric1" : "fabric2"), false);
                Procedural.Box(parent, "Table", new Vector3(x0 + 3.4f, y0 + 0.2f, zc), new Vector3(1.0f, 0.4f, 0.6f), Procedural.Mat("wood"), false);
            }
        }

        void BuildLiftAndSigns(Transform parent, int f)
        {
            float y0 = Layout.FloorY(f);
            Procedural.Box(parent, "LiftDoor", new Vector3(Layout.LiftX, y0 + 1.1f, 6.88f), new Vector3(1.6f, 2.2f, 0.05f), Procedural.Mat("metal"), false);
            var panel = Procedural.Box(parent, "LiftPanel", new Vector3(Layout.LiftX + 1.2f, y0 + 1.25f, 6.84f), new Vector3(0.3f, 0.5f, 0.12f), Procedural.Mat("dark"), true);
            Procedural.Box(panel.transform, "Btn", new Vector3(0f, 0.15f, -0.55f), new Vector3(0.4f, 0.3f, 0.2f), Procedural.Mat("hilite"), false);
            var it = panel.AddComponent<Interactable>();
            int floor = f;
            it.LabelFunc = () => "Call lift (floor " + Layout.FloorName(floor) + ")";
            it.OnInteract = () => { if (GameState.LiftRequested != null) GameState.LiftRequested(floor); };
            it.MaxDistance = 3.6f;

            Color txt = new Color(0.1f, 0.1f, 0.12f);
            Procedural.Label(parent, Layout.FloorName(f), new Vector3(1.4f, y0 + 2.45f, 6f), Quaternion.Euler(0f, -90f, 0f), 0.5f, txt);
            Procedural.Label(parent, Layout.FloorName(f), new Vector3(Layout.Length - 1.4f, y0 + 2.45f, 6f), Quaternion.Euler(0f, 90f, 0f), 0.5f, txt);
            // floor number visible from the street on the first pier of every storey
            if (f >= 1) Procedural.Label(parent, Layout.FloorName(f), new Vector3(0.45f, y0 + 1.6f, -0.14f), Quaternion.identity, 0.55f, new Color(0.15f, 0.12f, 0.1f));
            // fire extinguisher cabinet
            Procedural.Box(parent, "Extinguisher", new Vector3(6f, y0 + 1.1f, 6.85f), new Vector3(0.28f, 0.6f, 0.14f), Procedural.Mat("red"), false);
        }

        void BuildLobby(Transform parent)
        {
            Procedural.Box(parent, "Reception", new Vector3(18f, 0.55f, 2.2f), new Vector3(3.2f, 1.1f, 0.8f), Procedural.Mat("wood"));
            Procedural.Box(parent, "ReceptionTop", new Vector3(18f, 1.12f, 2.2f), new Vector3(3.4f, 0.06f, 1.0f), Procedural.Mat("dark"), false);
            Procedural.Box(parent, "LobbySofa", new Vector3(5f, 0.35f, 1.4f), new Vector3(2.6f, 0.7f, 0.9f), Procedural.Mat("fabric1"), false);
            Procedural.Box(parent, "LobbySofa", new Vector3(5f, 0.35f, 3.6f), new Vector3(2.6f, 0.7f, 0.9f), Procedural.Mat("fabric2"), false);
            Procedural.Cyl(parent, "PlantPot", new Vector3(9.3f, 0.3f, 4.4f), 0.6f, 0.6f, Procedural.Mat("concrete"));
            Procedural.Ball(parent, "Plant", new Vector3(9.3f, 0.95f, 4.4f), new Vector3(0.9f, 1.1f, 0.9f), Procedural.Mat("leaf2"));
            for (int i = 0; i < 4; i++)
                Procedural.Box(parent, "LobbyLight", new Vector3(5f + i * 4.5f, H - 0.28f, 2.5f), new Vector3(1.4f, 0.04f, 0.6f), Procedural.Mat("light"), false);
            Procedural.Label(parent, "LOBBY", new Vector3(12f, 2.4f, 4.85f), Quaternion.Euler(0f, 180f, 0f), 0.4f, new Color(0.1f, 0.1f, 0.12f));
        }

        // ------------------------------------------------------------------ stair cores
        void BuildCore(Transform parent, int core)
        {
            var c = new GameObject(core == 0 ? "StairCore_West" : "StairCore_East").transform;
            c.SetParent(parent, false);
            Material wall = Procedural.Mat("concrete");
            Material slab = Procedural.Mat("concrete");
            Material rampM = Procedural.Mat("floor");
            for (int f = 0; f < Layout.Floors; f++)
            {
                float y0 = Layout.FloorY(f);
                // enclosing walls
                Procedural.Box(c, "CoreBack", Layout.CorePoint(core, Layout.CoreDepth, 1.5f, y0 + H * 0.5f), new Vector3(0.2f, H, 3.2f), wall);
                float sideX = core == 0 ? -3f : Layout.Length + 3f;
                Procedural.Box(c, "CoreSideN", new Vector3(sideX, y0 + H * 0.5f, Layout.CoreZ1 + 0.1f), new Vector3(6.2f, H, 0.2f), wall);
                if (f == 0)
                {
                    // ground exit gap in the south side wall (u 0.15 .. 1.15)
                    float ux = 0.15f, gx = 1.15f;
                    float cx1 = core == 0 ? -(gx + Layout.CoreDepth) * 0.5f : Layout.Length + (gx + Layout.CoreDepth) * 0.5f;
                    Procedural.Box(c, "CoreSideS", new Vector3(cx1, y0 + H * 0.5f, Layout.CoreZ0 - 0.1f), new Vector3(Layout.CoreDepth - gx, H, 0.2f), wall);
                    float cx2 = core == 0 ? -ux * 0.5f : Layout.Length + ux * 0.5f;
                    Procedural.Box(c, "CoreSideS", new Vector3(cx2, y0 + H * 0.5f, Layout.CoreZ0 - 0.1f), new Vector3(ux, H, 0.2f), wall);
                    float cxh = core == 0 ? -(ux + gx) * 0.5f : Layout.Length + (ux + gx) * 0.5f;
                    Procedural.Box(c, "CoreExitHeader", new Vector3(cxh, y0 + 2.75f, Layout.CoreZ0 - 0.1f), new Vector3(gx - ux, 0.9f, 0.2f), wall);
                    Procedural.Box(c, "ExitSign", new Vector3(cxh, y0 + 2.3f, Layout.CoreZ0 + 0.05f), new Vector3(0.6f, 0.22f, 0.05f), Procedural.Mat("exit"), false);
                    Procedural.Label(c, "EXIT", new Vector3(cxh, y0 + 3.0f, Layout.CoreZ0 - 0.25f), Quaternion.Euler(0f, 180f, 0f), 0.35f, new Color(0.05f, 0.5f, 0.15f));
                }
                else
                {
                    Procedural.Box(c, "CoreSideS", new Vector3(sideX, y0 + H * 0.5f, Layout.CoreZ0 - 0.1f), new Vector3(6.2f, H, 0.2f), wall);
                }

                // near landing (floor level)
                float landThick = f == 0 ? 0.04f : 0.25f;
                float landY = f == 0 ? 0f : y0 - 0.125f;
                Procedural.Box(c, "NearLanding", Layout.CorePoint(core, Layout.NearLanding * 0.5f, 1.5f, landY), new Vector3(Layout.NearLanding, landThick, 3.0f), slab);
                // lane divider
                Procedural.Box(c, "LaneDivider", Layout.CorePoint(core, (Layout.NearLanding + Layout.RampEnd) * 0.5f, 1.5f, y0 + H * 0.5f), new Vector3(Layout.RampEnd - Layout.NearLanding, H, 0.1f), wall);

                if (f < Layout.Floors - 1)
                {
                    float mid = y0 + Layout.RampRise;
                    Procedural.Box(c, "FarLanding", Layout.CorePoint(core, 5.0f, 1.5f, mid - 0.125f), new Vector3(2.0f, 0.25f, 3.0f), slab);
                    Procedural.Ramp(c, "RampA", Layout.CorePoint(core, Layout.NearLanding, 0.75f, y0), Layout.CorePoint(core, Layout.RampEnd, 0.75f, mid), 1.4f, 0.2f, rampM);
                    Procedural.Ramp(c, "RampB", Layout.CorePoint(core, Layout.RampEnd, 2.25f, mid), Layout.CorePoint(core, Layout.NearLanding, 2.25f, y0 + H), 1.4f, 0.2f, rampM);
                }
                if (interior)
                    Procedural.Box(c, "StairLight", Layout.CorePoint(core, 3.0f, 1.5f, y0 + H - 0.1f), new Vector3(0.6f, 0.04f, 0.6f), Procedural.Mat("light"), false);
            }
            // cap
            Procedural.Box(c, "CoreRoof", Layout.CorePoint(core, 3.0f, 1.5f, Layout.FloorY(Layout.Floors) + 0.1f), new Vector3(6.4f, 0.3f, 3.4f), Procedural.Mat("roof"));
        }

        // ------------------------------------------------------------------ roof
        void BuildRoof(Transform parent)
        {
            float y = Layout.FloorY(Layout.Floors);
            Material roof = Procedural.Mat("roof");
            Procedural.Box(parent, "RoofSlab", new Vector3(12f, y - 0.125f, 6f), new Vector3(24.5f, 0.25f, 12.5f), roof);
            Procedural.Box(parent, "ParapetS", new Vector3(12f, y + 0.5f, 0f), new Vector3(24.5f, 1f, 0.3f), roof);
            Procedural.Box(parent, "ParapetN", new Vector3(12f, y + 0.5f, 12f), new Vector3(24.5f, 1f, 0.3f), roof);
            Procedural.Box(parent, "ParapetW", new Vector3(0f, y + 0.5f, 6f), new Vector3(0.3f, 1f, 12f), roof);
            Procedural.Box(parent, "ParapetE", new Vector3(24f, y + 0.5f, 6f), new Vector3(0.3f, 1f, 12f), roof);
            Procedural.Box(parent, "MachineRoom", new Vector3(12f, y + 1.5f, 6f), new Vector3(5f, 3f, 3.5f), Procedural.Mat("facade"));
            Procedural.Cyl(parent, "WaterTank", new Vector3(19f, y + 1.6f, 8.5f), 3f, 3.2f, Procedural.Mat("metal"));
            Procedural.Cyl(parent, "Antenna", new Vector3(5f, y + 4f, 8.5f), 0.12f, 8f, Procedural.Mat("dark"), false);
            Procedural.Ball(parent, "BeaconLight", new Vector3(5f, y + 8.1f, 8.5f), new Vector3(0.4f, 0.4f, 0.4f), Procedural.Mat("red"));
            Procedural.Label(parent, "URBANSIM TOWER", new Vector3(12f, y - 3.0f, -1.9f), Quaternion.identity, 0.9f, new Color(0.1f, 0.15f, 0.3f));
        }

        // ------------------------------------------------------------------ surroundings
        void BuildSurroundings(Transform p)
        {
            Procedural.Box(p, "Ground", new Vector3(12f, -0.15f, 6f), new Vector3(500f, 0.2f, 500f), Procedural.Mat("grass"));
            Procedural.Box(p, "Plaza", new Vector3(12f, -0.04f, 2.5f), new Vector3(44f, 0.08f, 23f), Procedural.Mat("plaza"));
            Procedural.Box(p, "Sidewalk", new Vector3(12f, -0.05f, -11f), new Vector3(500f, 0.1f, 4f), Procedural.Mat("plaza"));
            Procedural.Box(p, "Road", new Vector3(12f, -0.04f, -17f), new Vector3(500f, 0.02f, 10f), Procedural.Mat("asphalt"));
            for (int i = -40; i < 44; i++)
                Procedural.Box(p, "LaneMark", new Vector3(12f + i * 6f, -0.028f, -17f), new Vector3(2.5f, 0.01f, 0.2f), Procedural.Mat("line"), false);
            // walkway from entrance to sidewalk
            Procedural.Box(p, "Walkway", new Vector3(12f, -0.03f, -6f), new Vector3(6f, 0.03f, 12f), Procedural.Mat("concrete"), false);

            // entrance canopy
            Procedural.Box(p, "Canopy", new Vector3(12f, 3.3f, -1.6f), new Vector3(7.5f, 0.25f, 3.4f), Procedural.Mat("dark"));
            Procedural.Cyl(p, "CanopyColumn", new Vector3(8.6f, 1.6f, -3.1f), 0.3f, 3.2f, Procedural.Mat("metal"));
            Procedural.Cyl(p, "CanopyColumn", new Vector3(15.4f, 1.6f, -3.1f), 0.3f, 3.2f, Procedural.Mat("metal"));
            Procedural.Label(p, "URBANSIM TOWER", new Vector3(12f, 3.75f, -3.35f), Quaternion.identity, 0.35f, new Color(0.9f, 0.92f, 1f));

            // trees
            float[][] trees = {
                new[] { -14f, 18f }, new[] { -6f, 22f }, new[] { 4f, 24f }, new[] { 14f, 26f }, new[] { 24f, 22f }, new[] { 34f, 20f }, new[] { 42f, 16f },
                new[] { -20f, -2f }, new[] { 44f, -3f }, new[] { -26f, 10f }, new[] { 50f, 8f }, new[] { -2f, -8.6f }, new[] { 26f, -8.6f }, new[] { 40f, -8.6f }, new[] { -16f, -8.6f }
            };
            for (int i = 0; i < trees.Length; i++) Tree(p, trees[i][0], trees[i][1], 0.9f + (i % 3) * 0.2f);
            // bushes along the facade
            for (int i = 0; i < 9; i++)
            {
                float bx = -0.2f + i * 3f;
                if (bx > 7f && bx < 17f) continue;      // keep the entrance clear
                Procedural.Ball(p, "Bush", new Vector3(bx, 0.4f, -2.2f), new Vector3(1.4f, 0.9f, 1.2f), Procedural.Mat("leaf"));
            }
            // lamp posts
            for (int i = -2; i < 6; i++)
            {
                float x = i * 12f;
                Procedural.Cyl(p, "LampPost", new Vector3(x, 2.5f, -9.4f), 0.14f, 5f, Procedural.Mat("dark"));
                Procedural.Box(p, "LampHead", new Vector3(x, 5.05f, -9.7f), new Vector3(0.5f, 0.12f, 0.9f), Procedural.Mat("light"), false);
            }
            // parked cars on the road
            Color[] carColors = { new Color(0.7f, 0.1f, 0.1f), new Color(0.15f, 0.3f, 0.6f), new Color(0.85f, 0.85f, 0.85f), new Color(0.1f, 0.1f, 0.1f), new Color(0.9f, 0.7f, 0.1f) };
            float[] carX = { -8f, 4f, 28f, 40f, 58f };
            for (int i = 0; i < carX.Length; i++) Car(p, carX[i], -19.5f, carColors[i]);
            // neighbouring towers for context
            float[][] nb = {
                new[] { -70f, 50f, 24f, 16f, 40f }, new[] { -40f, 70f, 20f, 14f, 55f }, new[] { 10f, 85f, 30f, 18f, 35f },
                new[] { 60f, 70f, 22f, 16f, 48f }, new[] { 95f, 40f, 20f, 20f, 28f }, new[] { -100f, 10f, 22f, 22f, 30f }, new[] { 110f, -10f, 20f, 16f, 22f }
            };
            foreach (var b in nb)
            {
                Material wm = Procedural.WindowTower(b[2], b[4]);
                Procedural.Box(p, "Neighbour", new Vector3(b[0], b[4] * 0.5f, b[1]), new Vector3(b[2], b[4], b[3]), wm);
            }
        }

        void Tree(Transform p, float x, float z, float s)
        {
            Procedural.Cyl(p, "TreeTrunk", new Vector3(x, 1.3f * s, z), 0.4f * s, 2.6f * s, Procedural.Mat("trunk"));
            Procedural.Ball(p, "TreeCrown", new Vector3(x, 3.6f * s, z), new Vector3(3.2f * s, 3.0f * s, 3.2f * s), Procedural.Mat("leaf"));
            Procedural.Ball(p, "TreeCrown", new Vector3(x + 0.5f * s, 4.5f * s, z - 0.3f * s), new Vector3(2.2f * s, 2.0f * s, 2.2f * s), Procedural.Mat("leaf2"));
        }

        void Car(Transform p, float x, float z, Color c)
        {
            Material body = Procedural.Solid(c, 0.6f);
            Procedural.Box(p, "CarBody", new Vector3(x, 0.55f, z), new Vector3(4.3f, 0.7f, 1.8f), body);
            Procedural.Box(p, "CarCabin", new Vector3(x - 0.2f, 1.15f, z), new Vector3(2.2f, 0.6f, 1.6f), Procedural.Mat("glass"));
            for (int i = 0; i < 4; i++)
            {
                float wx = x + (i < 2 ? 1.4f : -1.4f);
                float wz = z + ((i % 2 == 0) ? 0.95f : -0.95f);
                Procedural.Prim(p, "Wheel", Procedural.Cylinder, new Vector3(wx, 0.32f, wz), new Vector3(0.64f, 0.12f, 0.64f), Quaternion.Euler(90f, 0f, 0f), Procedural.Mat("dark"), false);
            }
        }
    }
}
