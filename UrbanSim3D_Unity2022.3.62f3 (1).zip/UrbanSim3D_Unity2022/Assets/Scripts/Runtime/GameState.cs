using System;
using UnityEngine;

namespace UrbanSim
{
    public interface IScenario
    {
        string Title { get; }
        void EndNow();
    }

    /// <summary>Static session state. Reset by SceneBootstrap at the start of every scene.</summary>
    public static class GameState
    {
        public static ScenarioKind Selected = ScenarioKind.Fire;
        public static int FireLocationMode = 0;         // 0 apartment preset, 1 corridor preset, 2 random

        public static bool Paused;
        public static bool Modal;                        // briefing / results / lift selector open
        public static bool FreeCursor;                   // Tab toggles
        public static int SimSpeed = 1;
        public static IScenario Current;
        public static Action<int> LiftRequested;

        public static bool CursorFree { get { return Paused || Modal || FreeCursor; } }

        public static void ResetForScene()
        {
            Paused = false; Modal = false; FreeCursor = false; SimSpeed = 1;
            Current = null; LiftRequested = null;
            Time.timeScale = 1f;
        }
    }

    /// <summary>Something the player can look at and press E on.</summary>
    public class Interactable : MonoBehaviour
    {
        public string Label = "Interact";
        public Func<string> LabelFunc;
        public Func<bool> EnabledFunc;
        public Action OnInteract;
        public float MaxDistance = 3.4f;

        public string CurrentLabel { get { return LabelFunc != null ? LabelFunc() : Label; } }
        public bool IsEnabled { get { return EnabledFunc == null || EnabledFunc(); } }

        public void Activate()
        {
            if (IsEnabled && OnInteract != null) OnInteract();
        }
    }
}
