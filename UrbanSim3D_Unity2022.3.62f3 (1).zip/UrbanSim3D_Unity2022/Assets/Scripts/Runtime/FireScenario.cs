using System.Collections.Generic;
using UnityEngine;

namespace UrbanSim
{
    /// <summary>Scene driver for the residential fire and evacuation scenario. State rules live in FireModel.</summary>
    public class FireScenario : MonoBehaviour, IScenario, IModalSource
    {
        class Resident
        {
            public int Id, Floor, Apt, Core;
            public GameObject Go;
            public HumanoidRig Rig;
            public PathWalker Walker;
            public float Delay = -1f;      // < 0: not ordered yet
            public bool Started, Done;
        }

        public FireModel Model = new FireModel();
        public string Title { get { return "Fire Emergency"; } }
        public bool ModalOpen { get { return briefing || resultsOpen; } }

        BuildingBuilder world;
        PlayerController player;
        HudController hud;
        readonly List<Resident> residents = new List<Resident>();
        bool briefing = true, resultsOpen, recorded, ignited, sprinklersShown, evacOrdered;
        int evacSlot;

        // effects
        ParticleSystem flames, smokeApt, smokeCorr;
        readonly List<ParticleSystem> sprays = new List<ParticleSystem>();
        Light fireLight;
        GameObject charred, hazardApt, hazardCorr;
        AudioSource alarm, sprayAudio;
        float alarmFlash;
        System.Random rng;

        public void Init(BuildingBuilder b, PlayerController p, HudController h)
        {
            world = b; player = p; hud = h;
            hud.Scenario = this;
            hud.ModeTitle = "Fire Emergency";
            hud.ShowSpeedButtons = true;
            GameState.Current = this;
            ConfigureFromMode();
            Spawn();
        }

        void ConfigureFromMode()
        {
            int mode = GameState.FireLocationMode;
            rng = new System.Random(mode == 2 ? System.Environment.TickCount : 12345);
            if (mode == 0) Model.Configure(7, 1, false);
            else if (mode == 1) Model.Configure(12, 2, true);
            else Model.Configure(2 + rng.Next(0, 14), rng.Next(0, 8), rng.NextDouble() < 0.3);
            Model.Reset();
        }

        string LocationText
        {
            get
            {
                return Model.FireInCorridor
                    ? "Corridor, floor " + Layout.FloorName(Model.FireFloor)
                    : Layout.AptName(Model.FireFloor, Model.FireApt) + " (floor " + Layout.FloorName(Model.FireFloor) + ")";
            }
        }

        // ------------------------------------------------------------------ construction
        void Spawn()
        {
            for (int i = world.ScenarioRoot.childCount - 1; i >= 0; i--)
                Destroy(world.ScenarioRoot.GetChild(i).gameObject);
            residents.Clear(); sprays.Clear();
            ignited = sprinklersShown = evacOrdered = recorded = false;
            evacSlot = 0; alarmFlash = 0f;

            Transform root = world.ScenarioRoot;
            float y0 = Layout.FloorY(Model.FireFloor);
            float fx = Model.FireX, fz = Model.FireZ;

            // burning item + flames + light
            charred = Procedural.Box(root, "BurningItem", new Vector3(fx, y0 + 0.3f, fz), new Vector3(1.1f, 0.6f, 0.9f), Procedural.Mat("charred"), false);
            charred.SetActive(false);
            flames = Procedural.Flames(root, new Vector3(fx, y0 + 0.5f, fz), 1.3f);
            var lg = new GameObject("FireLight");
            lg.transform.SetParent(root, false);
            lg.transform.position = new Vector3(fx, y0 + 1.2f, fz);
            fireLight = lg.AddComponent<Light>();
            fireLight.type = LightType.Point; fireLight.color = new Color(1f, 0.5f, 0.15f);
            fireLight.range = 9f; fireLight.intensity = 0f; fireLight.shadows = LightShadows.None;

            // smoke emitters
            smokeApt = Procedural.Smoke(root, new Vector3(fx, y0 + 2.3f, fz), new Vector3(2f, 0.2f, 2f), 1.8f);
            smokeCorr = Procedural.Smoke(root, new Vector3(fx, y0 + 2.7f, Layout.CorridorMid), new Vector3(3f, 0.2f, 1.2f), 1.6f);

            // sprinkler heads and spray
            var heads = new List<Vector3>();
            if (!Model.FireInCorridor) heads.Add(new Vector3(fx, y0 + 3.0f, fz));
            for (int k = -1; k <= 1; k++)
                heads.Add(new Vector3(Mathf.Clamp(fx + k * 3f, 1.5f, 22.5f), y0 + 3.0f, Layout.CorridorMid));
            foreach (Vector3 h in heads)
            {
                Procedural.Cyl(root, "SprinklerHead", h + new Vector3(0f, 0.08f, 0f), 0.12f, 0.16f, Procedural.Mat("red"), false);
                sprays.Add(Procedural.Spray(root, h, 55f, 3.2f, 0f, new Color(0.7f, 0.85f, 1f, 0.8f), 0.07f));
            }

            // hazard decals (shown while smoke/fire makes the area unsafe)
            hazardCorr = Procedural.Box(root, "HazardCorridor", new Vector3(fx, y0 + 0.06f, Layout.CorridorMid), new Vector3(4f, 0.02f, 1.9f), Procedural.Solid(Color.red), false);
            hazardCorr.GetComponent<MeshRenderer>().sharedMaterial = Procedural.Sprite(new Color(0.9f, 0.1f, 0.05f, 0.35f), false);
            hazardCorr.SetActive(false);
            hazardApt = Procedural.Box(root, "HazardApartment", new Vector3(Layout.AptX(Model.FireApt), y0 + 0.06f, Layout.AptZ(Model.FireApt)), new Vector3(5.8f, 0.02f, 4.8f), Procedural.Solid(Color.red), false);
            hazardApt.GetComponent<MeshRenderer>().sharedMaterial = Procedural.Sprite(new Color(0.9f, 0.1f, 0.05f, 0.35f), false);
            hazardApt.SetActive(Model.HazardActive && !Model.FireInCorridor);
            hazardApt.SetActive(false);

            // safe assembly points
            for (int core = 0; core < 2; core++)
            {
                Vector3 c = Layout.AssemblyPoint(core, 2);
                var disc = Procedural.Cyl(root, "AssemblyPoint", new Vector3(c.x, 0.05f, c.z - 0.8f), 10f, 0.04f, Procedural.Solid(new Color(0.15f, 0.75f, 0.3f)), false);
                disc.GetComponent<MeshRenderer>().sharedMaterial = Procedural.Sprite(new Color(0.15f, 0.8f, 0.3f, 0.45f), false);
                Procedural.Cyl(root, "AssemblyPost", new Vector3(c.x, 1.4f, c.z + 2.8f), 0.1f, 2.8f, Procedural.Mat("metal"), false);
                Procedural.Box(root, "AssemblySign", new Vector3(c.x, 2.9f, c.z + 2.8f), new Vector3(3.2f, 0.9f, 0.08f), Procedural.Mat("exit"), false);
                Procedural.Label(root, "SAFE ASSEMBLY POINT", new Vector3(c.x, 2.9f, c.z + 2.7f), Quaternion.identity, 0.3f, Color.white);
            }

            // audio
            alarm = AudioLib.Make(root, "alarm", true, 0.35f, 0f);
            sprayAudio = AudioLib.Make(root, "spray", true, 0.3f, 0f);

            SpawnResidents(root);
        }

        static readonly Color[] shirts = {
            new Color(0.8f, 0.2f, 0.2f), new Color(0.2f, 0.5f, 0.8f), new Color(0.9f, 0.7f, 0.2f), new Color(0.3f, 0.7f, 0.4f),
            new Color(0.7f, 0.3f, 0.7f), new Color(0.95f, 0.95f, 0.95f), new Color(0.9f, 0.5f, 0.2f), new Color(0.25f, 0.3f, 0.5f) };
        static readonly Color[] skins = {
            new Color(0.95f, 0.78f, 0.65f), new Color(0.8f, 0.6f, 0.45f), new Color(0.6f, 0.42f, 0.3f), new Color(0.4f, 0.28f, 0.2f) };

        void SpawnResidents(Transform root)
        {
            var used = new HashSet<int>();
            var slots = new List<int[]>();
            int fireFloorCount = 0;
            if (!Model.FireInCorridor)
            {
                slots.Add(new[] { Model.FireFloor, Model.FireApt });
                used.Add(Model.FireFloor * 8 + Model.FireApt);
                fireFloorCount++;
            }
            var order = new List<int> { 0, 1, 2, 3, 4, 5, 6, 7 };
            Shuffle(order);
            foreach (int a in order)
            {
                if (fireFloorCount >= 3) break;
                int key = Model.FireFloor * 8 + a;
                if (used.Contains(key)) continue;
                slots.Add(new[] { Model.FireFloor, a }); used.Add(key); fireFloorCount++;
            }
            var pool = new List<int[]>();
            int lo = Mathf.Max(1, Model.FireFloor - 5), hi = Mathf.Min(Layout.Floors - 1, Model.FireFloor + 7);
            for (int f = lo; f <= hi; f++)
                for (int a = 0; a < 8; a++)
                    if (!used.Contains(f * 8 + a)) pool.Add(new[] { f, a });
            for (int i = pool.Count - 1; i > 0; i--) { int j = rng.Next(0, i + 1); int[] t = pool[i]; pool[i] = pool[j]; pool[j] = t; }
            for (int i = 0; slots.Count < 24 && i < pool.Count; i++) slots.Add(pool[i]);

            int id = 0;
            foreach (int[] s in slots)
            {
                var r = new Resident { Id = id, Floor = s[0], Apt = s[1] };
                Vector3 c = Layout.AptCenter(r.Floor, r.Apt);
                Vector3 pos = new Vector3(c.x + (float)(rng.NextDouble() * 2.4 - 1.2), c.y, c.z + (float)(rng.NextDouble() * 1.6 - 0.8));
                r.Rig = Procedural.Humanoid(root, "Resident_" + id, shirts[rng.Next(0, shirts.Length)], new Color(0.2f, 0.22f, 0.3f),
                    skins[rng.Next(0, skins.Length)], new Color(0.12f, 0.08f, 0.05f));
                r.Go = r.Rig.gameObject;
                r.Go.transform.position = pos;
                r.Go.transform.rotation = Quaternion.Euler(0f, (float)(rng.NextDouble() * 360.0), 0f);
                r.Walker = r.Go.AddComponent<PathWalker>();
                r.Walker.Rig = r.Rig;
                r.Walker.Speed = 1.9f + (float)rng.NextDouble() * 0.5f;
                Resident captured = r;
                r.Walker.OnArrived = () => { captured.Done = true; Model.ReportEvacuated(); };
                var it = r.Go.AddComponent<Interactable>();
                it.LabelFunc = () => "Talk to resident (" + Layout.AptName(captured.Floor, captured.Apt) + ")";
                it.OnInteract = () => hud.Toast(ResidentLine(captured));
                residents.Add(r);
                id++;
            }
        }

        void Shuffle(List<int> l)
        {
            for (int i = l.Count - 1; i > 0; i--) { int j = rng.Next(0, i + 1); int t = l[i]; l[i] = l[j]; l[j] = t; }
        }

        string ResidentLine(Resident r)
        {
            if (briefing || Model.Phase == FirePhase.Normal) return "Resident: Everything is normal here.";
            if (r.Done) return "Resident: I'm at the assembly point. Is everyone out?";
            if (r.Started) return "Resident: I'm using the stairs, not the lift!";
            return "Resident: The alarm is ringing - I'm getting ready to leave.";
        }

        // ------------------------------------------------------------------ flow
        void StartScenario()
        {
            briefing = false;
            Model.Begin(residents.Count);
            hud.Toast("Scenario started - normal conditions. Observe the building.");
        }

        public void EndNow()
        {
            if (briefing || Model.Phase == FirePhase.Complete) return;
            if (Model.Phase == FirePhase.Normal) { hud.Toast("The fire has not started yet."); return; }
            Model.Finish(false);
        }

        void OnIgnition()
        {
            ignited = true;
            charred.SetActive(true);
            foreach (Resident r in residents)
                if (!Model.FireInCorridor && r.Floor == Model.FireFloor && r.Apt == Model.FireApt) Order(r, 0.6f);
            hud.Toast("FIRE at " + LocationText + " - alarm sounding!", 6f);
        }

        void OnSprinklers()
        {
            sprinklersShown = true;
            hud.Toast("Sprinklers activated in the affected area. Smoke can still make areas unsafe.", 7f);
        }

        void OnEvacOrdered()
        {
            evacOrdered = true;
            hud.Toast("Evacuation ordered - use the stairs, avoid smoke.", 6f);
            foreach (Resident r in residents)
                if (r.Delay < 0f)
                    Order(r, r.Floor == Model.FireFloor ? 0.5f + (float)rng.NextDouble() * 2f : 1f + (float)rng.NextDouble() * 6f);
        }

        void Order(Resident r, float delay)
        {
            if (r.Delay >= 0f) return;
            r.Delay = delay;
        }

        void StartWalking(Resident r)
        {
            r.Started = true;
            RouteChoice route = Model.ChooseRoute(r.Floor, r.Apt);
            r.Core = route.Core;
            var path = new List<Vector3>();
            float y = Layout.FloorY(r.Floor);
            Vector3 door = Layout.AptDoor(r.Floor, r.Apt);
            bool south = Layout.AptSide(r.Apt) == 0;
            path.Add(new Vector3(door.x, y, south ? 4.0f : 8.0f));
            path.Add(new Vector3(door.x, y, door.z));
            path.Add(new Vector3(door.x, y, Layout.CorridorMid));
            path.Add(new Vector3(Layout.CoreX(route.Core), y, Layout.CorridorMid));
            path.Add(Layout.CorePoint(route.Core, 0.6f, 1.5f, y));
            for (int f = r.Floor; f >= 1; f--) path.AddRange(Layout.StairDescent(route.Core, f));
            path.Add(Layout.CorePoint(route.Core, 0.6f, 0.3f, 0f));
            path.Add(Layout.CorePoint(route.Core, 0.6f, -1.5f, 0f));
            path.Add(Layout.AssemblyPoint(route.Core, evacSlot++));
            r.Walker.SetPath(path);
        }

        // ------------------------------------------------------------------ per-frame
        void Update()
        {
            if (briefing) return;
            float dt = Time.deltaTime;
            Model.Tick(dt);

            if (!ignited && Model.Phase >= FirePhase.FireStarted) OnIgnition();
            if (!sprinklersShown && Model.SprinklersActive) OnSprinklers();
            if (!evacOrdered && Model.Phase >= FirePhase.Evacuation) OnEvacOrdered();

            foreach (Resident r in residents)
            {
                if (r.Delay >= 0f && !r.Started)
                {
                    r.Delay -= dt;
                    if (r.Delay <= 0f) StartWalking(r);
                }
                if (r.Started && !r.Done && Model.IsHazardAt(r.Go.transform.position))
                    Model.AddResidentExposure(r.Id, dt);
            }
            if (player != null && Model.IsHazardAt(player.transform.position)) Model.AddPlayerExposure(dt);

            UpdateEffects();
            if (Model.Phase == FirePhase.Complete && !recorded) Complete();
        }

        void UpdateEffects()
        {
            float fi = Model.FireIntensity;
            Procedural.SetRate(flames, fi > 0.03f ? fi * 45f : 0f);
            fireLight.intensity = fi * (2.2f + 1.4f * Mathf.PerlinNoise(Time.time * 7f, 0.3f));
            float corrFactor = Mathf.Clamp01((Model.SinceIgnition - 3f) / 6f);
            Procedural.SetRate(smokeApt, Model.FireInCorridor ? 0f : Model.SmokeLevel * 36f);
            Procedural.SetRate(smokeCorr, Model.SmokeLevel * 30f * (Model.FireInCorridor ? 1f : corrFactor));
            var sh = smokeCorr.shape;
            sh.scale = new Vector3(Model.CorridorRadius * 2f, 0.2f, 1.2f);

            bool spr = Model.SprinklersActive && Model.Phase != FirePhase.Complete;
            foreach (ParticleSystem s in sprays) Procedural.SetRate(s, spr ? 150f : 0f);
            if (spr) AudioLib.Play(sprayAudio); else AudioLib.Stop(sprayAudio);

            if (Model.AlarmOn && Model.Phase != FirePhase.Complete) AudioLib.Play(alarm); else AudioLib.Stop(alarm);

            bool haz = Model.HazardActive;
            hazardCorr.SetActive(haz);
            if (haz) hazardCorr.transform.localScale = new Vector3(Model.CorridorRadius * 2f, 0.02f, 1.9f);
            hazardApt.SetActive(haz && !Model.FireInCorridor);
        }

        void Complete()
        {
            recorded = true;
            SaveSystem.Append(Model.BuildRecord());
            resultsOpen = true;
            hud.Toast("Scenario complete - see results.", 6f);
        }

        // ------------------------------------------------------------------ UI
        void OnGUI()
        {
            Gui.Begin();
            float W = Gui.W, H = Gui.H;
            if (briefing) DrawBriefing(W, H);
            else
            {
                DrawStatus(W, H);
                if (resultsOpen) DrawResults(W, H);
            }
            Gui.End();
        }

        void DrawBriefing(float W, float H)
        {
            Gui.DimScreen(0.5f);
            var r = new Rect(W * 0.5f - 400, H * 0.5f - 290, 800, 580);
            Gui.PanelBox(r);
            Gui.Label(new Rect(r.x + 28, r.y + 14, r.width - 56, 44), "SCENARIO A  -  Residential Building Fire", Gui.Heading, Gui.Accent);
            string text =
                "You are observing a 20-storey residential tower during a fire drill.\n\n" +
                "1  Normal conditions - residents are at home.\n" +
                "2  Fire starts - flames, smoke and the alarm begin.\n" +
                "3  Emergency response - sprinklers act on the affected area, but smoke still makes areas unsafe.\n" +
                "4  Evacuation - residents use the stairs; track who is out and who is still inside.\n" +
                "5  Results - time, residents out, hazard exposure.\n\n" +
                "Walk around, use the lifts (E on the dark panel by the lift doors) to reach any floor and watch the evacuation routes. " +
                "This is a training simulation, not a certified fire-physics model.";
            Gui.Label(new Rect(r.x + 28, r.y + 62, r.width - 56, 290), text, Gui.BodyWrap);
            Gui.Label(new Rect(r.x + 28, r.y + 360, 300, 28), "Fire location", Gui.Body, Gui.Accent);
            string[] names = { "Apartment preset", "Corridor preset", "Random" };
            for (int i = 0; i < 3; i++)
                if (Gui.BtnSelected(new Rect(r.x + 28 + i * 190, r.y + 392, 180, 38), names[i], GameState.FireLocationMode == i))
                {
                    GameState.FireLocationMode = i;
                    ConfigureFromMode();
                    Spawn();
                }
            Gui.Label(new Rect(r.x + 28, r.y + 436, r.width - 56, 28), "Selected: " + LocationText + "   |   Residents: " + residents.Count, Gui.Small);
            if (Gui.BtnBig(new Rect(r.x + 28, r.y + 480, 300, 60), "Start Scenario")) StartScenario();
            if (Gui.Btn(new Rect(r.x + r.width - 228, r.y + 488, 200, 44), "Main menu")) HudController.GoMenu();
        }

        string StageMark(int stage)
        {
            int cur = (int)Model.Phase;      // Normal=1 ... Evacuation=4, Complete=5
            if (Model.Phase == FirePhase.Sprinklers) cur = 3;
            if (stage < cur || Model.Phase == FirePhase.Complete) return "<color=#4dd96f>[done]</color> ";
            if (stage == cur) return "<color=#ffa31f>[now]</color> ";
            return "<color=#8a93a6>[ ]</color> ";
        }

        void DrawStatus(float W, float H)
        {
            var p = new Rect(14, 48, 340, 468);
            Gui.PanelBox(p);
            float y = p.y + 8;
            Gui.Label(new Rect(p.x + 12, y, p.width - 24, 26), "Incident: Building fire", Gui.Body, Gui.Accent);
            y += 28;
            string[] stages = { "Normal conditions", "Fire starts - alarm", "Emergency response", "Evacuation", "Results" };
            for (int i = 0; i < 5; i++)
            {
                Gui.Label(new Rect(p.x + 12, y, p.width - 24, 22), StageMark(i + 1) + (i + 1) + ". " + stages[i], Gui.Small);
                y += 22;
            }
            y += 6;
            Gui.Label(new Rect(p.x + 12, y, p.width - 24, 22), "Time: " + Fmt.Time(Model.Elapsed) + "   (limit " + Fmt.Time(Model.TimeLimit) + ")", Gui.Body); y += 26;
            Gui.Label(new Rect(p.x + 12, y, p.width - 24, 22), "Location: " + LocationText, Gui.Small); y += 24;
            string fire = !ignited ? "No fire" : (Model.SprinklersActive && Model.FireIntensity < 0.3f ? "Suppressed - smoke persists" : "Growing");
            Gui.Label(new Rect(p.x + 12, y, p.width - 24, 22), "Fire: " + fire, Gui.Small); y += 22;
            Gui.Label(new Rect(p.x + 12, y, p.width - 24, 22), "Sprinklers: " + (Model.SprinklersActive ? "<color=#4dd96f>ACTIVE (fire area)</color>" : "standby"), Gui.Small); y += 22;
            Gui.Label(new Rect(p.x + 12, y, p.width - 24, 22), "Smoke level: " + Mathf.RoundToInt(Model.SmokeLevel * 100f) + "%", Gui.Small); y += 22;
            string w = Model.IsCoreSmoky(0) ? "<color=#ff6b5a>SMOKY - avoid</color>" : "<color=#4dd96f>clear</color>";
            string e = Model.IsCoreSmoky(1) ? "<color=#ff6b5a>SMOKY - avoid</color>" : "<color=#4dd96f>clear</color>";
            Gui.Label(new Rect(p.x + 12, y, p.width - 24, 22), "West stair: " + w + "    East stair: " + e, Gui.Small); y += 28;

            Gui.Label(new Rect(p.x + 12, y, p.width - 24, 22), "Residents: " + Model.TotalResidents, Gui.Body); y += 24;
            Gui.Label(new Rect(p.x + 12, y, p.width - 24, 22), "Evacuated: <color=#4dd96f>" + Model.Evacuated + "</color>    Remaining: <color=#ffa31f>" + Model.Remaining + "</color>", Gui.Body); y += 26;
            Gui.Progress(new Rect(p.x + 12, y, p.width - 24, 16), Model.TotalResidents > 0 ? (float)Model.Evacuated / Model.TotalResidents : 0f, Gui.Good); y += 24;
            Gui.Label(new Rect(p.x + 12, y, p.width - 24, 22), "Hazard exposure: " + Model.ExposureSeconds.ToString("0") + " resident-s (" + Model.ExposedResidents + " residents)", Gui.Small); y += 24;
            if (Gui.Btn(new Rect(p.x + 12, y, p.width - 24, 32), "Go to fire floor (lift level)"))
            {
                if (player != null) { player.Teleport(Layout.LiftArrival(Model.FireFloor) + new Vector3(0f, 0.05f, -0.2f), 0f); hud.Toast("Floor " + Layout.FloorName(Model.FireFloor) + " - stay out of smoke zones (red floor)."); }
            }
            y += 38;
            if (Gui.Btn(new Rect(p.x + 12, y, p.width - 24, 32), resultsOpen ? "Hide results" : "Show results")) { if (Model.Phase == FirePhase.Complete) resultsOpen = !resultsOpen; else hud.Toast("Results appear when the scenario is complete."); }

            // banner
            string banner = null; Color bc = Gui.Accent;
            switch (Model.Phase)
            {
                case FirePhase.Normal: banner = "Normal conditions - the fire starts in a few seconds"; bc = Gui.Good; break;
                case FirePhase.FireStarted: banner = "FIRE EMERGENCY  -  alarm active"; bc = Gui.Bad; break;
                case FirePhase.Sprinklers: banner = "Sprinklers active - smoke still hazardous"; bc = Gui.Accent; break;
                case FirePhase.Evacuation: banner = "EVACUATION IN PROGRESS  -  " + Model.Remaining + " residents inside"; bc = Gui.Bad; break;
                case FirePhase.Complete: banner = Model.Evacuated >= Model.TotalResidents ? "Scenario complete - all residents evacuated" : "Scenario ended"; bc = Gui.Good; break;
            }
            if (banner != null)
            {
                var br = new Rect(W * 0.5f - 300, 44, 600, 32);
                Gui.PanelBox(br);
                Gui.Label(br, banner, Gui.Center, bc);
            }

            if (Model.AlarmOn && Model.Phase != FirePhase.Complete)
            {
                alarmFlash += Time.unscaledDeltaTime;
                float a = 0.12f + 0.1f * Mathf.Sin(alarmFlash * 7f);
                Gui.Fill(new Rect(0, 0, W, 5), new Color(1f, 0f, 0f, a * 4f));
                Gui.Fill(new Rect(0, H - 5, W, 5), new Color(1f, 0f, 0f, a * 4f));
            }
            if (player != null && Model.IsHazardAt(player.transform.position))
            {
                Gui.Fill(new Rect(0, 0, W, H), new Color(0.15f, 0.12f, 0.1f, 0.35f));
                var hr = new Rect(W * 0.5f - 280, H * 0.5f - 120, 560, 40);
                Gui.PanelBox(hr);
                Gui.Label(hr, "SMOKE HAZARD ZONE - leave the red area", Gui.Center, Gui.Bad);
            }
        }

        void DrawResults(float W, float H)
        {
            Gui.DimScreen(0.55f);
            var r = new Rect(W * 0.5f - 340, H * 0.5f - 260, 680, 520);
            Gui.PanelBox(r);
            bool all = Model.Evacuated >= Model.TotalResidents;
            Gui.Label(new Rect(r.x + 28, r.y + 14, r.width - 56, 40), "FIRE SCENARIO RESULTS", Gui.Heading, Gui.Accent);
            string status = all ? "<color=#4dd96f>COMPLETE - all residents evacuated</color>"
                          : (Model.TimedOut ? "<color=#ff6b5a>INCOMPLETE - time limit reached</color>" : "<color=#ffa31f>ENDED EARLY</color>");
            string lines =
                "Status:  " + status + "\n\n" +
                "Total residents:  " + Model.TotalResidents + "\n" +
                "Residents evacuated:  " + Model.Evacuated + "\n" +
                "Residents remaining:  " + Model.Remaining + "\n" +
                "Time taken:  " + Fmt.Time(Model.Elapsed) + "\n\n" +
                "Hazard exposure:  " + Model.ExposureSeconds.ToString("0.0") + " resident-seconds, " + Model.ExposedResidents + " residents passed through smoke or fire areas\n" +
                "Route safety:  " + Model.RouteSafetyLabel + "\n" +
                "Your own time in smoke zones:  " + Model.PlayerExposureSeconds.ToString("0.0") + " s\n\n" +
                "Result saved to your training history.";
            Gui.Label(new Rect(r.x + 28, r.y + 62, r.width - 56, 330), lines, Gui.BodyWrap);
            if (Gui.BtnBig(new Rect(r.x + 28, r.y + 430, 190, 56), "Restart")) HudController.Restart();
            if (Gui.Btn(new Rect(r.x + 232, r.y + 438, 200, 44), "Main menu")) HudController.GoMenu();
            if (Gui.Btn(new Rect(r.x + 446, r.y + 438, 200, 44), "Keep exploring")) resultsOpen = false;
        }
    }
}
