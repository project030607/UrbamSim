using System;
using System.Collections.Generic;
using UnityEngine;

namespace UrbanSim
{
    /// <summary>Procedural meshes, materials, textures, particles and characters. No external art is required.</summary>
    public static class Procedural
    {
        static Mesh cubeMesh, cylMesh, sphereMesh;
        static readonly Dictionary<string, Material> mats = new Dictionary<string, Material>();
        static readonly Dictionary<string, Texture2D> texs = new Dictionary<string, Texture2D>();
        static Material baseMat;
        static Material spriteMat;
        static Texture2D softCircle;
        static Font font;

        // ------------------------------------------------------------ meshes
        static Mesh PrimMesh(PrimitiveType t)
        {
            var go = GameObject.CreatePrimitive(t);
            Mesh m = go.GetComponent<MeshFilter>().sharedMesh;
            if (Application.isPlaying) UnityEngine.Object.Destroy(go); else UnityEngine.Object.DestroyImmediate(go);
            return m;
        }

        public static Mesh Cube { get { if (cubeMesh == null) cubeMesh = PrimMesh(PrimitiveType.Cube); return cubeMesh; } }
        public static Mesh Cylinder { get { if (cylMesh == null) cylMesh = PrimMesh(PrimitiveType.Cylinder); return cylMesh; } }
        public static Mesh Sphere { get { if (sphereMesh == null) sphereMesh = PrimMesh(PrimitiveType.Sphere); return sphereMesh; } }

        public static GameObject Prim(Transform parent, string name, Mesh mesh, Vector3 pos, Vector3 scale, Quaternion rot, Material m, bool collider)
        {
            var go = new GameObject(name);
            if (parent != null) go.transform.SetParent(parent, false);
            go.transform.localPosition = pos;
            go.transform.localRotation = rot;
            go.transform.localScale = scale;
            go.AddComponent<MeshFilter>().sharedMesh = mesh;
            go.AddComponent<MeshRenderer>().sharedMaterial = m;
            if (collider)
            {
                if (mesh == Cube) go.AddComponent<BoxCollider>();
                else if (mesh == Sphere) go.AddComponent<SphereCollider>();
                else go.AddComponent<CapsuleCollider>();
            }
            return go;
        }

        public static GameObject Box(Transform parent, string name, Vector3 center, Vector3 size, Material m, bool collider = true)
        {
            return Prim(parent, name, Cube, center, size, Quaternion.identity, m, collider);
        }

        public static GameObject BoxRot(Transform parent, string name, Vector3 center, Vector3 size, Quaternion rot, Material m, bool collider)
        {
            return Prim(parent, name, Cube, center, size, rot, m, collider);
        }

        /// <summary>Upright cylinder: diameter x height (centre position).</summary>
        public static GameObject Cyl(Transform parent, string name, Vector3 center, float diameter, float height, Material m, bool collider = true)
        {
            return Prim(parent, name, Cylinder, center, new Vector3(diameter, height * 0.5f, diameter), Quaternion.identity, m, collider);
        }

        public static GameObject Ball(Transform parent, string name, Vector3 center, Vector3 size, Material m, bool collider = false)
        {
            return Prim(parent, name, Sphere, center, size, Quaternion.identity, m, collider);
        }

        /// <summary>A sloped slab whose top surface runs exactly from a to b.</summary>
        public static GameObject Ramp(Transform parent, string name, Vector3 a, Vector3 b, float width, float thickness, Material m)
        {
            Vector3 d = b - a;
            float len = d.magnitude;
            Quaternion rot = Quaternion.LookRotation(d.normalized, Vector3.up);
            Vector3 up = rot * Vector3.up;
            Vector3 center = (a + b) * 0.5f - up * (thickness * 0.5f);
            return Prim(parent, name, Cube, center, new Vector3(width, thickness, len), rot, m, true);
        }

        // ------------------------------------------------------------ textures
        static float Hash(int x, int y, int seed)
        {
            unchecked
            {
                int h = x * 374761393 + y * 668265263 + seed * 144665;
                h = (h ^ (h >> 13)) * 1274126177;
                h ^= h >> 16;
                return (h & 0xFFFF) / 65535f;
            }
        }

        static float ValueNoise(float x, float y, int seed)
        {
            int xi = Mathf.FloorToInt(x), yi = Mathf.FloorToInt(y);
            float fx = x - xi, fy = y - yi;
            fx = fx * fx * (3f - 2f * fx); fy = fy * fy * (3f - 2f * fy);
            float a = Hash(xi, yi, seed), b = Hash(xi + 1, yi, seed), c = Hash(xi, yi + 1, seed), d = Hash(xi + 1, yi + 1, seed);
            return Mathf.Lerp(Mathf.Lerp(a, b, fx), Mathf.Lerp(c, d, fx), fy);
        }

        static Texture2D MakeTex(int size, Func<int, int, Color> fn)
        {
            var t = new Texture2D(size, size, TextureFormat.RGBA32, true);
            var px = new Color32[size * size];
            for (int y = 0; y < size; y++)
                for (int x = 0; x < size; x++)
                    px[y * size + x] = fn(x, y);
            t.SetPixels32(px);
            t.wrapMode = TextureWrapMode.Repeat;
            t.filterMode = FilterMode.Bilinear;
            t.Apply(true);
            return t;
        }

        public static Texture2D Tex(string name)
        {
            Texture2D t;
            if (texs.TryGetValue(name, out t) && t != null) return t;
            switch (name)
            {
                case "concrete":
                    t = MakeTex(128, (x, y) => { float n = 0.86f + 0.14f * ValueNoise(x / 16f, y / 16f, 1) + 0.05f * Hash(x, y, 2); return new Color(n * 0.9f, n * 0.9f, n * 0.88f); });
                    break;
                case "grass":
                    t = MakeTex(128, (x, y) => { float n = 0.55f + 0.3f * ValueNoise(x / 10f, y / 10f, 3) + 0.15f * Hash(x, y, 4); return new Color(0.22f * n + 0.08f, 0.5f * n + 0.1f, 0.18f * n + 0.04f); });
                    break;
                case "asphalt":
                    t = MakeTex(128, (x, y) => { float n = 0.28f + 0.1f * Hash(x, y, 5) + 0.05f * ValueNoise(x / 8f, y / 8f, 6); return new Color(n, n, n * 1.04f); });
                    break;
                case "tile":
                    t = MakeTex(128, (x, y) =>
                    {
                        bool grout = (x % 64) < 2 || (y % 64) < 2;
                        bool alt = ((x / 64) + (y / 64)) % 2 == 0;
                        float n = (alt ? 0.82f : 0.74f) + 0.03f * Hash(x, y, 7);
                        return grout ? new Color(0.5f, 0.5f, 0.48f) : new Color(n, n * 0.97f, n * 0.9f);
                    });
                    break;
                case "windows":
                    t = MakeTex(64, (x, y) =>
                    {
                        bool pane = (x % 16) >= 4 && (x % 16) < 13 && (y % 16) >= 4 && (y % 16) < 13;
                        float lit = Hash(x / 16, y / 16, 8) > 0.72f ? 1f : 0f;
                        if (pane) return lit > 0.5f ? new Color(0.95f, 0.88f, 0.6f) : new Color(0.25f, 0.33f, 0.45f);
                        return new Color(0.62f, 0.6f, 0.58f);
                    });
                    break;
                default:
                    t = MakeTex(8, (x, y) => Color.white);
                    break;
            }
            t.hideFlags = HideFlags.DontSave;
            texs[name] = t;
            return t;
        }

        public static Texture2D SoftCircle
        {
            get
            {
                if (softCircle == null)
                {
                    softCircle = MakeTex(32, (x, y) =>
                    {
                        float dx = (x - 15.5f) / 15.5f, dy = (y - 15.5f) / 15.5f;
                        float a = Mathf.Clamp01(1f - Mathf.Sqrt(dx * dx + dy * dy));
                        return new Color(1f, 1f, 1f, a * a);
                    });
                    softCircle.wrapMode = TextureWrapMode.Clamp;
                    softCircle.hideFlags = HideFlags.DontSave;
                }
                return softCircle;
            }
        }

        // ------------------------------------------------------------ materials
        static Material Base()
        {
            if (baseMat == null)
            {
                baseMat = Resources.Load<Material>("UrbanSim/BaseStandard");
                if (baseMat == null)
                {
                    Shader s = Shader.Find("Standard");
                    if (s == null) s = Shader.Find("Legacy Shaders/Diffuse");
                    baseMat = new Material(s);
                }
            }
            return baseMat;
        }

        static Material Make(Color c, float smooth, float metal, Texture2D tex, float tx, float ty, Color? emission)
        {
            var m = new Material(Base());
            m.color = c;
            if (m.HasProperty("_Glossiness")) m.SetFloat("_Glossiness", smooth);
            if (m.HasProperty("_Metallic")) m.SetFloat("_Metallic", metal);
            if (tex != null) { m.mainTexture = tex; m.mainTextureScale = new Vector2(tx, ty); }
            if (emission.HasValue)
            {
                m.EnableKeyword("_EMISSION");
                m.SetColor("_EmissionColor", emission.Value);
            }
            m.hideFlags = HideFlags.DontSave;
            return m;
        }

        public static Material Solid(Color c, float smooth = 0.15f)
        {
            string key = "solid_" + ColorUtility.ToHtmlStringRGB(c) + "_" + smooth.ToString("0.00");
            Material m;
            if (mats.TryGetValue(key, out m) && m != null) return m;
            m = Make(c, smooth, 0f, null, 1, 1, null);
            mats[key] = m;
            return m;
        }

        public static Material Mat(string key)
        {
            Material m;
            if (mats.TryGetValue(key, out m) && m != null) return m;
            switch (key)
            {
                case "concrete": m = Make(Color.white, 0.08f, 0f, Tex("concrete"), 1, 1, null); break;
                case "facade": m = Make(new Color(0.9f, 0.88f, 0.82f), 0.1f, 0f, Tex("concrete"), 1, 1, null); break;
                case "pier0": m = Make(new Color(0.78f, 0.62f, 0.45f), 0.1f, 0f, Tex("concrete"), 1, 1, null); break;
                case "pier1": m = Make(new Color(0.66f, 0.7f, 0.76f), 0.1f, 0f, Tex("concrete"), 1, 1, null); break;
                case "pier2": m = Make(new Color(0.72f, 0.58f, 0.58f), 0.1f, 0f, Tex("concrete"), 1, 1, null); break;
                case "pier3": m = Make(new Color(0.62f, 0.7f, 0.6f), 0.1f, 0f, Tex("concrete"), 1, 1, null); break;
                case "glass": m = Make(new Color(0.18f, 0.3f, 0.42f), 0.92f, 0.35f, null, 1, 1, null); break;
                case "floor": m = Make(Color.white, 0.25f, 0f, Tex("tile"), 12, 6, null); break;
                case "wall": m = Make(new Color(0.93f, 0.9f, 0.82f), 0.05f, 0f, null, 1, 1, null); break;
                case "wallAlt": m = Make(new Color(0.8f, 0.86f, 0.9f), 0.05f, 0f, null, 1, 1, null); break;
                case "door": m = Make(new Color(0.45f, 0.28f, 0.15f), 0.3f, 0f, null, 1, 1, null); break;
                case "metal": m = Make(new Color(0.7f, 0.72f, 0.75f), 0.7f, 0.8f, null, 1, 1, null); break;
                case "dark": m = Make(new Color(0.12f, 0.12f, 0.14f), 0.2f, 0f, null, 1, 1, null); break;
                case "railing": m = Make(new Color(0.85f, 0.9f, 0.95f), 0.6f, 0.3f, null, 1, 1, null); break;
                case "red": m = Make(new Color(0.8f, 0.1f, 0.08f), 0.4f, 0f, null, 1, 1, null); break;
                case "exit": m = Make(new Color(0.05f, 0.6f, 0.2f), 0.3f, 0f, null, 1, 1, new Color(0.1f, 0.9f, 0.3f)); break;
                case "light": m = Make(new Color(1f, 1f, 0.95f), 0.1f, 0f, null, 1, 1, new Color(1f, 0.97f, 0.85f)); break;
                case "grass": m = Make(Color.white, 0.02f, 0f, Tex("grass"), 150, 150, null); break;
                case "asphalt": m = Make(Color.white, 0.05f, 0f, Tex("asphalt"), 60, 3, null); break;
                case "plaza": m = Make(new Color(0.8f, 0.78f, 0.74f), 0.1f, 0f, Tex("concrete"), 8, 4, null); break;
                case "line": m = Make(new Color(0.95f, 0.95f, 0.9f), 0.1f, 0f, null, 1, 1, null); break;
                case "trunk": m = Make(new Color(0.35f, 0.24f, 0.14f), 0.05f, 0f, null, 1, 1, null); break;
                case "leaf": m = Make(new Color(0.18f, 0.45f, 0.17f), 0.05f, 0f, null, 1, 1, null); break;
                case "leaf2": m = Make(new Color(0.25f, 0.55f, 0.2f), 0.05f, 0f, null, 1, 1, null); break;
                case "roof": m = Make(new Color(0.4f, 0.4f, 0.42f), 0.05f, 0f, Tex("concrete"), 1, 1, null); break;
                case "fabric1": m = Make(new Color(0.35f, 0.4f, 0.55f), 0.05f, 0f, null, 1, 1, null); break;
                case "fabric2": m = Make(new Color(0.6f, 0.35f, 0.3f), 0.05f, 0f, null, 1, 1, null); break;
                case "wood": m = Make(new Color(0.55f, 0.38f, 0.22f), 0.25f, 0f, null, 1, 1, null); break;
                case "charred": m = Make(new Color(0.08f, 0.06f, 0.05f), 0.05f, 0f, null, 1, 1, new Color(0.5f, 0.1f, 0.02f)); break;
                case "white": m = Make(new Color(0.92f, 0.92f, 0.92f), 0.5f, 0.1f, null, 1, 1, null); break;
                case "copper": m = Make(new Color(0.75f, 0.42f, 0.25f), 0.6f, 0.9f, null, 1, 1, null); break;
                case "pipeLeak": m = Make(new Color(0.8f, 0.45f, 0.28f), 0.6f, 0.9f, null, 1, 1, new Color(0.35f, 0.18f, 0.05f)); break;
                case "hilite": m = Make(new Color(1f, 0.85f, 0.1f), 0.2f, 0f, null, 1, 1, new Color(1f, 0.7f, 0f)); break;
                default: m = Make(Color.gray, 0.1f, 0f, null, 1, 1, null); break;
            }
            mats[key] = m;
            return m;
        }

        /// <summary>Unlit alpha-blended material for decals, hazard zones and particles.</summary>
        public static Material Sprite(Color tint, bool soft)
        {
            Shader s = Shader.Find("Sprites/Default");
            if (s == null) s = Base().shader;
            var m = new Material(s);
            m.color = tint;
            if (soft) m.mainTexture = SoftCircle;
            m.hideFlags = HideFlags.DontSave;
            return m;
        }

        public static Material ParticleMat()
        {
            if (spriteMat == null) spriteMat = Sprite(Color.white, true);
            return spriteMat;
        }

        public static Material WindowTower(float w, float h)
        {
            var m = Make(Color.white, 0.1f, 0f, Tex("windows"), Mathf.Max(1f, w / 3.2f), Mathf.Max(1f, h / 3.2f), null);
            return m;
        }

        // ------------------------------------------------------------ text
        public static TextMesh Label(Transform parent, string text, Vector3 pos, Quaternion rot, float height, Color color)
        {
            if (font == null) font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            var go = new GameObject("Label_" + text);
            if (parent != null) go.transform.SetParent(parent, false);
            go.transform.localPosition = pos;
            go.transform.localRotation = rot;
            var tm = go.AddComponent<TextMesh>();
            tm.font = font;
            tm.text = text;
            tm.fontSize = 64;
            tm.characterSize = height * 10f / 64f;
            tm.anchor = TextAnchor.MiddleCenter;
            tm.alignment = TextAlignment.Center;
            tm.color = color;
            var mr = go.GetComponent<MeshRenderer>();
            if (mr == null) mr = go.AddComponent<MeshRenderer>();
            mr.sharedMaterial = font.material;
            return tm;
        }

        // ------------------------------------------------------------ particles
        public static ParticleSystem NewParticles(Transform parent, string name, Vector3 localPos, Quaternion localRot)
        {
            var go = new GameObject(name);
            go.transform.SetParent(parent, false);
            go.transform.localPosition = localPos;
            go.transform.localRotation = localRot;
            var ps = go.AddComponent<ParticleSystem>();
            ps.Stop(true, ParticleSystemStopBehavior.StopEmittingAndClear);
            var r = go.GetComponent<ParticleSystemRenderer>();
            r.sharedMaterial = ParticleMat();
            r.renderMode = ParticleSystemRenderMode.Billboard;
            r.shadowCastingMode = UnityEngine.Rendering.ShadowCastingMode.Off;
            r.receiveShadows = false;
            return ps;
        }

        static Gradient Fade(Color c, float startAlpha)
        {
            var g = new Gradient();
            g.SetKeys(
                new[] { new GradientColorKey(c, 0f), new GradientColorKey(c, 1f) },
                new[] { new GradientAlphaKey(0f, 0f), new GradientAlphaKey(startAlpha, 0.15f), new GradientAlphaKey(0f, 1f) });
            return g;
        }

        public static ParticleSystem Flames(Transform parent, Vector3 pos, float scale)
        {
            var ps = NewParticles(parent, "Flames", pos, Quaternion.Euler(-90f, 0f, 0f));
            var main = ps.main;
            main.loop = true; main.playOnAwake = false;
            main.startLifetime = new ParticleSystem.MinMaxCurve(0.5f, 1.0f);
            main.startSpeed = new ParticleSystem.MinMaxCurve(0.8f * scale, 1.8f * scale);
            main.startSize = new ParticleSystem.MinMaxCurve(0.5f * scale, 1.1f * scale);
            main.startColor = new ParticleSystem.MinMaxGradient(new Color(1f, 0.55f, 0.1f), new Color(1f, 0.85f, 0.2f));
            main.maxParticles = 90;
            main.simulationSpace = ParticleSystemSimulationSpace.World;
            var shape = ps.shape; shape.enabled = true; shape.shapeType = ParticleSystemShapeType.Cone; shape.angle = 12f; shape.radius = 0.5f * scale;
            var col = ps.colorOverLifetime; col.enabled = true;
            var g = new Gradient();
            g.SetKeys(new[] { new GradientColorKey(new Color(1f, 0.9f, 0.4f), 0f), new GradientColorKey(new Color(1f, 0.35f, 0.05f), 0.5f), new GradientColorKey(new Color(0.3f, 0.05f, 0.02f), 1f) },
                      new[] { new GradientAlphaKey(0f, 0f), new GradientAlphaKey(0.9f, 0.2f), new GradientAlphaKey(0f, 1f) });
            col.color = new ParticleSystem.MinMaxGradient(g);
            var size = ps.sizeOverLifetime; size.enabled = true;
            size.size = new ParticleSystem.MinMaxCurve(1f, new AnimationCurve(new Keyframe(0f, 0.6f), new Keyframe(0.4f, 1f), new Keyframe(1f, 0.1f)));
            var em = ps.emission; em.rateOverTime = 0f;
            return ps;
        }

        public static ParticleSystem Smoke(Transform parent, Vector3 pos, Vector3 boxSize, float size)
        {
            var ps = NewParticles(parent, "Smoke", pos, Quaternion.identity);
            var main = ps.main;
            main.loop = true; main.playOnAwake = false;
            main.startLifetime = new ParticleSystem.MinMaxCurve(4f, 7f);
            main.startSpeed = new ParticleSystem.MinMaxCurve(0.1f, 0.4f);
            main.startSize = new ParticleSystem.MinMaxCurve(size * 0.8f, size * 1.6f);
            main.startColor = new ParticleSystem.MinMaxGradient(new Color(0.12f, 0.12f, 0.12f, 1f), new Color(0.3f, 0.3f, 0.3f, 1f));
            main.gravityModifier = -0.02f;
            main.maxParticles = 140;
            main.simulationSpace = ParticleSystemSimulationSpace.World;
            var shape = ps.shape; shape.enabled = true; shape.shapeType = ParticleSystemShapeType.Box; shape.scale = boxSize;
            var col = ps.colorOverLifetime; col.enabled = true;
            col.color = new ParticleSystem.MinMaxGradient(Fade(Color.white, 0.55f));
            var sz = ps.sizeOverLifetime; sz.enabled = true;
            sz.size = new ParticleSystem.MinMaxCurve(1f, new AnimationCurve(new Keyframe(0f, 0.5f), new Keyframe(1f, 1.4f)));
            var em = ps.emission; em.rateOverTime = 0f;
            return ps;
        }

        public static ParticleSystem Spray(Transform parent, Vector3 pos, float coneAngle, float speed, float rate, Color c, float size)
        {
            var ps = NewParticles(parent, "Spray", pos, Quaternion.Euler(90f, 0f, 0f));   // points down
            var main = ps.main;
            main.loop = true; main.playOnAwake = false;
            main.startLifetime = new ParticleSystem.MinMaxCurve(0.6f, 1.0f);
            main.startSpeed = new ParticleSystem.MinMaxCurve(speed * 0.7f, speed);
            main.startSize = new ParticleSystem.MinMaxCurve(size * 0.6f, size);
            main.startColor = c;
            main.gravityModifier = 1.2f;
            main.maxParticles = 220;
            main.simulationSpace = ParticleSystemSimulationSpace.World;
            var shape = ps.shape; shape.enabled = true; shape.shapeType = ParticleSystemShapeType.Cone; shape.angle = coneAngle; shape.radius = 0.04f;
            var col = ps.colorOverLifetime; col.enabled = true;
            col.color = new ParticleSystem.MinMaxGradient(Fade(Color.white, 0.8f));
            var em = ps.emission; em.rateOverTime = rate;
            return ps;
        }

        public static void SetRate(ParticleSystem ps, float rate)
        {
            if (ps == null) return;
            var em = ps.emission;
            em.rateOverTime = rate;
            if (rate > 0.01f) { if (!ps.isPlaying) ps.Play(); }
            else if (ps.isPlaying) ps.Stop(true, ParticleSystemStopBehavior.StopEmitting);
        }

        // ------------------------------------------------------------ characters
        public static HumanoidRig Humanoid(Transform parent, string name, Color shirt, Color pants, Color skin, Color hair)
        {
            var root = new GameObject(name);
            if (parent != null) root.transform.SetParent(parent, false);
            Transform t = root.transform;
            Box(t, "Torso", new Vector3(0f, 1.12f, 0f), new Vector3(0.46f, 0.62f, 0.26f), Solid(shirt), false);
            Ball(t, "Head", new Vector3(0f, 1.6f, 0f), new Vector3(0.26f, 0.28f, 0.26f), Solid(skin));
            Ball(t, "Hair", new Vector3(0f, 1.68f, -0.015f), new Vector3(0.28f, 0.17f, 0.28f), Solid(hair));
            var rig = root.AddComponent<HumanoidRig>();
            rig.LegL = Limb(t, "LegL", new Vector3(-0.11f, 0.82f, 0f), new Vector3(0.17f, 0.8f, 0.2f), 0.4f, Solid(pants));
            rig.LegR = Limb(t, "LegR", new Vector3(0.11f, 0.82f, 0f), new Vector3(0.17f, 0.8f, 0.2f), 0.4f, Solid(pants));
            rig.ArmL = Limb(t, "ArmL", new Vector3(-0.31f, 1.4f, 0f), new Vector3(0.12f, 0.6f, 0.14f), 0.28f, Solid(shirt));
            rig.ArmR = Limb(t, "ArmR", new Vector3(0.31f, 1.4f, 0f), new Vector3(0.12f, 0.6f, 0.14f), 0.28f, Solid(shirt));
            var col = root.AddComponent<CapsuleCollider>();
            col.center = new Vector3(0f, 0.9f, 0f); col.radius = 0.35f; col.height = 1.8f; col.isTrigger = true;
            return rig;
        }

        static Transform Limb(Transform parent, string name, Vector3 pivotPos, Vector3 size, float centerDrop, Material m)
        {
            var pivot = new GameObject(name);
            pivot.transform.SetParent(parent, false);
            pivot.transform.localPosition = pivotPos;
            Box(pivot.transform, "Mesh", new Vector3(0f, -centerDrop, 0f), size, m, false);
            return pivot.transform;
        }
    }

    /// <summary>Procedural walk / idle animation for the primitive characters.</summary>
    public class HumanoidRig : MonoBehaviour
    {
        public Transform LegL, LegR, ArmL, ArmR;
        public bool Walking;
        public bool Working;
        float phase;

        void Update()
        {
            float dt = Time.deltaTime;
            if (Walking)
            {
                phase += dt * 9f;
                float s = Mathf.Sin(phase) * 32f;
                if (LegL != null) LegL.localRotation = Quaternion.Euler(s, 0f, 0f);
                if (LegR != null) LegR.localRotation = Quaternion.Euler(-s, 0f, 0f);
                if (ArmL != null) ArmL.localRotation = Quaternion.Euler(-s * 0.8f, 0f, 0f);
                if (ArmR != null) ArmR.localRotation = Quaternion.Euler(s * 0.8f, 0f, 0f);
            }
            else
            {
                phase += dt * 3f;
                if (LegL != null) LegL.localRotation = Quaternion.identity;
                if (LegR != null) LegR.localRotation = Quaternion.identity;
                float sway = Mathf.Sin(phase) * 3f;
                if (Working)
                {
                    if (ArmR != null) ArmR.localRotation = Quaternion.Euler(-70f + Mathf.Sin(phase * 4f) * 25f, 0f, 0f);
                    if (ArmL != null) ArmL.localRotation = Quaternion.Euler(-40f, 0f, 0f);
                }
                else
                {
                    if (ArmL != null) ArmL.localRotation = Quaternion.Euler(sway, 0f, 0f);
                    if (ArmR != null) ArmR.localRotation = Quaternion.Euler(-sway, 0f, 0f);
                }
            }
        }
    }

    /// <summary>Walks along a list of waypoints at a fixed speed.</summary>
    public class PathWalker : MonoBehaviour
    {
        public float Speed = 2f;
        public HumanoidRig Rig;
        readonly List<Vector3> queue = new List<Vector3>();
        int index;
        public bool HasPath { get { return index < queue.Count; } }
        public Action OnArrived;

        public void SetPath(List<Vector3> pts)
        {
            queue.Clear();
            if (pts != null) queue.AddRange(pts);
            index = 0;
            if (Rig != null) Rig.Walking = queue.Count > 0;
        }

        void Update()
        {
            if (index >= queue.Count) return;
            Vector3 target = queue[index];
            Vector3 to = target - transform.position;
            Vector3 flat = new Vector3(to.x, 0f, to.z);
            if (flat.sqrMagnitude > 0.0004f)
                transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.LookRotation(flat.normalized, Vector3.up), Time.deltaTime * 10f);
            transform.position = Vector3.MoveTowards(transform.position, target, Speed * Time.deltaTime);
            if ((transform.position - target).sqrMagnitude < 0.0004f)
            {
                index++;
                if (index >= queue.Count)
                {
                    if (Rig != null) Rig.Walking = false;
                    if (OnArrived != null) OnArrived();
                }
            }
        }
    }
}
