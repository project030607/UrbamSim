using UnityEngine;

namespace UrbanSim
{
    /// <summary>First-person walker: WASD, mouse look, wheel zoom, E interact, collision via CharacterController.</summary>
    [RequireComponent(typeof(CharacterController))]
    public class PlayerController : MonoBehaviour
    {
        public static PlayerController Instance;

        public Camera Cam;
        public Interactable Focus { get; private set; }
        public float WalkSpeed = 3.8f;
        public float RunSpeed = 6.5f;
        public float LookSensitivity = 2.2f;

        CharacterController cc;
        float yaw, pitch, vy;
        Vector3 spawn;
        float spawnYaw;

        public int CurrentFloor { get { return Layout.FloorAt(transform.position.y); } }

        public static PlayerController Create(Vector3 position, float yawDegrees)
        {
            var go = new GameObject("Player");
            go.transform.position = position;
            var c = go.AddComponent<CharacterController>();
            c.height = 1.8f; c.radius = 0.3f; c.center = new Vector3(0f, 0.9f, 0f);
            c.stepOffset = 0.45f; c.slopeLimit = 50f; c.skinWidth = 0.05f;
            var p = go.AddComponent<PlayerController>();

            var camGo = new GameObject("PlayerCamera");
            camGo.transform.SetParent(go.transform, false);
            camGo.transform.localPosition = new Vector3(0f, 1.62f, 0f);
            var cam = camGo.AddComponent<Camera>();
            cam.fieldOfView = 65f; cam.nearClipPlane = 0.08f; cam.farClipPlane = 600f;
            cam.clearFlags = CameraClearFlags.SolidColor;
            cam.backgroundColor = new Color(0.62f, 0.78f, 0.95f);
            camGo.tag = "MainCamera";
            camGo.AddComponent<AudioListener>();
            var lamp = new GameObject("Headlamp");
            lamp.transform.SetParent(camGo.transform, false);
            var l = lamp.AddComponent<Light>();
            l.type = LightType.Point; l.range = 9f; l.intensity = 0.55f; l.shadows = LightShadows.None;
            l.color = new Color(1f, 0.96f, 0.88f);

            p.Cam = cam;
            p.spawn = position; p.spawnYaw = yawDegrees;
            p.yaw = yawDegrees;
            return p;
        }

        void Awake()
        {
            Instance = this;
            cc = GetComponent<CharacterController>();
        }

        void OnDestroy() { if (Instance == this) Instance = null; }

        public void Teleport(Vector3 position, float yawDegrees)
        {
            cc.enabled = false;
            transform.position = position;
            cc.enabled = true;
            yaw = yawDegrees; pitch = 0f; vy = 0f;
            transform.rotation = Quaternion.Euler(0f, yaw, 0f);
            Cam.transform.localRotation = Quaternion.identity;
        }

        public void TryInteract()
        {
            if (Focus != null) Focus.Activate();
        }

        void Update()
        {
            bool free = GameState.CursorFree;
            Cursor.lockState = free ? CursorLockMode.None : CursorLockMode.Locked;
            Cursor.visible = free;

            float dt = Time.unscaledDeltaTime;
            if (dt > 0.1f) dt = 0.1f;

            if (!free)
            {
                yaw += Input.GetAxis("Mouse X") * LookSensitivity;
                pitch = Mathf.Clamp(pitch - Input.GetAxis("Mouse Y") * LookSensitivity, -80f, 80f);
                transform.rotation = Quaternion.Euler(0f, yaw, 0f);
                Cam.transform.localRotation = Quaternion.Euler(pitch, 0f, 0f);

                float wheel = Input.mouseScrollDelta.y;
                if (Mathf.Abs(wheel) > 0.01f)
                    Cam.fieldOfView = Mathf.Clamp(Cam.fieldOfView - wheel * 4f, 30f, 85f);
            }

            Vector3 move = Vector3.zero;
            if (!free)
            {
                float h = Input.GetAxisRaw("Horizontal");
                float v = Input.GetAxisRaw("Vertical");
                move = transform.right * h + transform.forward * v;
                if (move.sqrMagnitude > 1f) move.Normalize();
                move *= Input.GetKey(KeyCode.LeftShift) ? RunSpeed : WalkSpeed;
            }
            if (cc.isGrounded) vy = -1.5f; else vy -= 22f * dt;
            move.y = vy;
            if (cc.enabled) cc.Move(move * dt);

            if (transform.position.y < -30f) Teleport(spawn, spawnYaw);

            // look for something to interact with
            Focus = null;
            if (!free)
            {
                RaycastHit hit;
                if (Physics.Raycast(Cam.transform.position, Cam.transform.forward, out hit, 4f, ~0, QueryTriggerInteraction.Collide))
                {
                    var it = hit.collider.GetComponentInParent<Interactable>();
                    if (it != null && it.IsEnabled && hit.distance <= it.MaxDistance) Focus = it;
                }
                if (Input.GetKeyDown(KeyCode.E)) TryInteract();
            }
        }
    }
}
