using System.Collections.Generic;
using UnityEngine;

namespace UrbanSim
{
    /// <summary>Scene driver for the water-leak report, investigation and repair scenario. Rules live in LeakModel.</summary>
    public class LeakScenario : MonoBehaviour, IScenario, IModalSource
    {
        enum PlumberState { None, ToLift, InLift, ToApt, OnSite }

        public LeakModel Model = new LeakModel();
        public string Title { get { return "Water Leakage"; } }
        public bool ModalOpen { get { return briefing || resultsOpen; } }

        BuildingBuilder world;
        PlayerController player;
        HudController hud;
        bool briefing = true, resultsOpen, recorded;
        System.Random rng;

        // objects
        GameObject residentGo, alertMark, panelGo, pipesGo, puddle, plumberGo;
        HumanoidRig plumberRig;
        PathWalker plumberWalker;
        ParticleSystem jointSpray, drips;
        AudioSource leakAudio;
        PlumberState pState = PlumberState.None;
        float liftTimer;
        bool repairing; float repairProgress;
        Vector3 jointPos, workPos;
        float x0, zc, y0;

        public void Init(BuildingBuilder b, PlayerController p, HudController h)
        {
            world = b; player = p; hud = h;
            hud.Scenario = this;
            hud.ModeTitle = "Water Leakage";
            hud.ShowSpeedButtons = true;
            GameState.Current = this;
            rng = new System.Random(System.Environment.TickCount);
            Model.Reset();
            Model.Floor = 3 + rng.Next(0, 14);
            Model.Apt = rng.Next(0, 8);
            Spawn();
        }

        string LocationText { get { return Layout.AptName(Model.Floor, Model.Apt) + ", floor " + Layout.FloorName(Model.Floor) + " (kitchen utility wall)"; } }

        // ------------------------------------------------------------------ construction
        void Spawn()
        {
            Transform root = world.ScenarioRoot;
            y0 = Layout.FloorY(Model.Floor);
            x0 = Layout.AptCol(Model.Apt) * Layout.AptWidth;
            zc = Layout.AptZ(Model.Apt);
            jointPos = new Vector3(x0 + 0.3f, y0 + 1.3f, zc + 0.2f);
            workPos = new Vector3(x0 + 1.5f, y0, zc + 0.2f);

            // resident who will report
            var rig = Procedural.Humanoid(root, "Resident", new Color(0.25f, 0.55f, 0.75f), new Color(0.2f, 0.2f, 0.28f), new Color(0.85f, 0.65f, 0.5f), new Color(0.25f, 0.15f, 0.08f));
            residentGo = rig.gameObject;
            residentGo.transform.position = new Vector3(x0 + 2.2f, y0, zc - (Layout.AptSide(Model.Apt) == 0 ? -0.5f : 0.5f));
            residentGo.transform.rotation = Quaternion.LookRotation(new Vector3(-1f, 0f, 0.2f));
            var rit = residentGo.AddComponent<Interactable>();
            rit.LabelFunc = () => Model.Phase == LeakPhase.Initial ? "Talk to resident - report the leak" : "Talk to resident";
            rit.OnInteract = () =>
            {
                if (Model.Phase == LeakPhase.Initial) { hud.Toast("Resident: Water is coming through my kitchen wall!"); Report(); }
                else hud.Toast("Resident: Please hurry - the water keeps spreading.");
            };
            alertMark = Procedural.Label(residentGo.transform, "!", new Vector3(0f, 2.15f, 0f), Quaternion.identity, 0.5f, Color.red).gameObject;

            // fixtures along the utility wall
            var sink = Procedural.Box(root, "SinkCabinet", new Vector3(x0 + 0.5f, y0 + 0.45f, zc - 1.3f), new Vector3(0.72f, 0.92f, 1.02f), Procedural.Mat("wood"), true);
            AddInspect(sink, LeakModel.PointSink, "Inspect sink supply pipe");
            var heater = Procedural.Cyl(root, "WaterHeater", new Vector3(x0 + 0.5f, y0 + 0.7f, zc + 1.5f), 0.55f, 1.4f, Procedural.Mat("white"), true);
            AddInspect(heater, LeakModel.PointHeater, "Inspect water heater connection");

            panelGo = Procedural.Box(root, "AccessPanel", new Vector3(x0 + 0.15f, y0 + 1.3f, zc + 0.2f), new Vector3(0.05f, 0.8f, 0.7f), Procedural.Mat("metal"), true);
            var pit = panelGo.AddComponent<Interactable>();
            pit.LabelFunc = () => "Open wall access panel";
            pit.EnabledFunc = () => !briefing && Model.Phase != LeakPhase.Failed;
            pit.OnInteract = () => Inspect(LeakModel.PointPanel);

            // hidden plumbing behind the panel
            pipesGo = new GameObject("HiddenPlumbing");
            pipesGo.transform.SetParent(root, false);
            Transform pt = pipesGo.transform;
            Procedural.Cyl(pt, "RiserPipe", new Vector3(x0 + 0.2f, y0 + 1.3f, zc + 0.2f), 0.08f, 1.2f, Procedural.Mat("copper"), false);
            Procedural.Prim(pt, "BranchPipe", Procedural.Cylinder, new Vector3(x0 + 0.5f, y0 + 1.0f, zc + 0.2f), new Vector3(0.07f, 0.3f, 0.07f), Quaternion.Euler(0f, 0f, 90f), Procedural.Mat("copper"), false);
            var joint = Procedural.Ball(pt, "LeakingJoint", jointPos, new Vector3(0.2f, 0.2f, 0.2f), Procedural.Mat("pipeLeak"), true);
            var jit = joint.AddComponent<Interactable>();
            jit.LabelFunc = () => repairing ? "Repairing pipe joint..." : "Repair pipe joint";
            jit.EnabledFunc = () => Model.Located && !Model.Stopped;
            jit.OnInteract = StartRepair;
            var valve = Procedural.Ball(pt, "ShutOffValve", new Vector3(x0 + 0.35f, y0 + 1.75f, zc + 0.2f), new Vector3(0.18f, 0.18f, 0.18f), Procedural.Mat("red"), true);
            var vit = valve.AddComponent<Interactable>();
            vit.LabelFunc = () => Model.ValveClosed ? "Shut-off valve (closed)" : "Close shut-off valve";
            vit.EnabledFunc = () => Model.Located && !Model.Stopped && !Model.ValveClosed;
            vit.OnInteract = () => { if (Model.CloseValve()) hud.Toast("Supply shut off - the leak slows. Now repair the joint."); };
            pipesGo.SetActive(false);

            // water
            puddle = Procedural.Box(root, "Puddle", new Vector3(x0 + 0.9f, y0 + 0.05f, zc + 0.2f), new Vector3(0.7f, 0.02f, 0.7f), Procedural.Solid(Color.blue), true);
            puddle.GetComponent<MeshRenderer>().sharedMaterial = Procedural.Sprite(new Color(0.2f, 0.45f, 0.85f, 0.6f), false);
            AddInspect(puddle, LeakModel.PointClue, "Inspect water on the floor");
            drips = Procedural.Spray(root, new Vector3(x0 + 0.25f, y0 + 0.95f, zc + 0.2f), 20f, 0.3f, 0f, new Color(0.6f, 0.8f, 1f, 0.9f), 0.04f);
            jointSpray = Procedural.Spray(root, jointPos + new Vector3(0.1f, 0f, 0f), 35f, 1.8f, 0f, new Color(0.7f, 0.85f, 1f, 0.85f), 0.06f);
            leakAudio = AudioLib.Make(root, "spray", true, 0f, 1f);
            leakAudio.transform.position = jointPos;
            leakAudio.transform.localPosition = jointPos;

            // plumber (waits outside until the report)
            var prig = Procedural.Humanoid(root, "Plumber", new Color(0.95f, 0.5f, 0.1f), new Color(0.15f, 0.25f, 0.5f), new Color(0.8f, 0.6f, 0.45f), new Color(0.1f, 0.08f, 0.05f));
            plumberGo = prig.gameObject; plumberRig = prig;
            Procedural.Ball(plumberGo.transform, "Helmet", new Vector3(0f, 1.72f, 0f), new Vector3(0.32f, 0.2f, 0.32f), Procedural.Mat("hilite"), false);
            Procedural.Box(plumberGo.transform, "Toolbox", new Vector3(0.42f, 0.4f, 0f), new Vector3(0.3f, 0.2f, 0.16f), Procedural.Mat("red"), false);
            plumberWalker = plumberGo.AddComponent<PathWalker>();
            plumberWalker.Rig = prig; plumberWalker.Speed = 2.4f;
            plumberWalker.OnArrived = OnPlumberArrived;
            plumberGo.SetActive(false);
        }

        void AddInspect(GameObject go, string point, string label)
        {
            var it = go.GetComponent<Interactable>();
            if (it == null) it = go.AddComponent<Interactable>();
            it.Label = label;
            it.EnabledFunc = () => !briefing && Model.Phase != LeakPhase.Failed;
            string p = point;
            it.OnInteract = () => Inspect(p);
        }

        // ------------------------------------------------------------------ flow
        void StartScenario()
        {
            briefing = false;
            hud.Toast("Find the resident in the building and report the leak (or use the Report button).");
        }

        void Report()
        {
            if (!Model.Report()) return;
            if (alertMark != null) alertMark.SetActive(false);
            hud.Toast("Leak reported at " + Layout.AptName(Model.Floor, Model.Apt) + ". Plumber dispatched - response timer running.", 6f);
            plumberGo.SetActive(true);
            plumberGo.transform.position = new Vector3(12f, 0f, -7f);
            pState = PlumberState.ToLift;
            plumberWalker.SetPath(new List<Vector3> { new Vector3(12f, 0f, 2f), new Vector3(12f, 0f, 5.6f), new Vector3(12f, 0f, 6.0f) });
        }

        void OnPlumberArrived()
        {
            if (pState == PlumberState.ToLift)
            {
                pState = PlumberState.InLift;
                liftTimer = 3f + Model.Floor * 0.6f;
                plumberGo.SetActive(false);
            }
            else if (pState == PlumberState.ToApt)
            {
                pState = PlumberState.OnSite;
                Model.PlumberArrived();
                plumberGo.transform.rotation = Quaternion.LookRotation(new Vector3(-1f, 0f, 0f));
                hud.Toast("The plumber has arrived and is waiting for you to find the source.", 5f);
            }
        }

        void Inspect(string point)
        {
            switch (Model.Inspect(point))
            {
                case InspectOutcome.Clue:
                    hud.Toast("The water is trailing from the wall beside the kitchen unit - look for an access panel.");
                    break;
                case InspectOutcome.Wrong:
                    hud.Toast("Dry. This is not the source (wrong inspections: " + Model.WrongInspections + ").");
                    break;
                case InspectOutcome.SourceFound:
                    panelGo.SetActive(false);
                    pipesGo.SetActive(true);
                    hud.Toast("LEAK LOCATED: ruptured joint behind the panel. Close the red valve, then repair the joint.", 7f);
                    break;
                case InspectOutcome.AlreadyLocated:
                    hud.Toast("The source is already located.");
                    break;
                default:
                    hud.Toast("Nobody has reported a leak yet.");
                    break;
            }
        }

        void StartRepair()
        {
            if (repairing) return;
            if (!Model.PlumberOnSite) { hud.Toast("Wait for the plumber to arrive with the fittings."); return; }
            if (!Model.ValveClosed) { hud.Toast("Close the shut-off valve before repairing the joint."); return; }
            repairing = true; repairProgress = 0f;
            plumberRig.Working = true;
            hud.Toast("Repairing... stay close to the joint.");
        }

        public void EndNow()
        {
            if (briefing || Model.Finished) return;
            if (Model.Phase == LeakPhase.Initial) { hud.Toast("Nothing to end yet - the leak has not been reported."); return; }
            Model.Abandon();
        }

        // ------------------------------------------------------------------ per-frame
        void Update()
        {
            if (briefing) return;
            float dt = Time.deltaTime;
            Model.Tick(dt);

            if (pState == PlumberState.InLift)
            {
                liftTimer -= dt;
                if (liftTimer <= 0f)
                {
                    pState = PlumberState.ToApt;
                    plumberGo.SetActive(true);
                    plumberGo.transform.position = Layout.LiftArrival(Model.Floor);
                    Vector3 door = Layout.AptDoor(Model.Floor, Model.Apt);
                    bool south = Layout.AptSide(Model.Apt) == 0;
                    plumberWalker.SetPath(new List<Vector3> {
                        new Vector3(door.x, y0, Layout.CorridorMid), new Vector3(door.x, y0, door.z),
                        new Vector3(door.x, y0, south ? 4.0f : 8.0f), workPos });
                }
            }

            if (repairing)
            {
                bool near = player == null || Vector3.Distance(player.transform.position, jointPos) < 6f;
                if (!near) { repairing = false; plumberRig.Working = false; hud.Toast("Repair interrupted - you moved too far away."); }
                else
                {
                    repairProgress += dt / 3f;
                    if (repairProgress >= 1f)
                    {
                        repairing = false; plumberRig.Working = false;
                        if (Model.TryRepair() == RepairOutcome.Repaired) hud.Toast("Joint replaced - the leak has stopped. Status: Repaired.", 6f);
                    }
                }
            }

            UpdateEffects();
            if (Model.Finished && !recorded) Complete();
        }

        void UpdateEffects()
        {
            float rate = Model.LeakRate;
            bool open = Model.Located;
            Procedural.SetRate(jointSpray, open ? rate * 90f : 0f);
            Procedural.SetRate(drips, open ? rate * 14f : rate * 12f);
            float size = Mathf.Min(3.6f, 0.7f + Model.SpilledLitres * 0.06f);
            puddle.transform.localScale = new Vector3(size, 0.02f, size);
            puddle.transform.position = new Vector3(x0 + 0.3f + size * 0.5f, y0 + 0.05f, zc + 0.2f);
            leakAudio.volume = Model.Finished ? 0f : 0.35f * rate;
            if (rate > 0f && !Model.Finished) AudioLib.Play(leakAudio); else AudioLib.Stop(leakAudio);
        }

        void Complete()
        {
            recorded = true;
            SaveSystem.Append(Model.BuildRecord());
            resultsOpen = true;
        }

        string PlumberText
        {
            get
            {
                switch (pState)
                {
                    case PlumberState.None: return "Not dispatched";
                    case PlumberState.ToLift: return "Entering the building";
                    case PlumberState.InLift: return "In the lift to floor " + Layout.FloorName(Model.Floor);
                    case PlumberState.ToApt: return "Walking to the apartment";
                    default: return "On site";
                }
            }
        }

        // ------------------------------------------------------------------ UI
        void OnGUI()
        {
            Gui.Begin();
            float W = Gui.W, H = Gui.H;
            if (briefing) DrawBriefing(W, H);
            else
            {
                DrawStatus(W, H);
                if (resultsOpen) DrawResults(W, H);
            }
            Gui.End();
        }

        void DrawBriefing(float W, float H)
        {
            Gui.DimScreen(0.5f);
            var r = new Rect(W * 0.5f - 400, H * 0.5f - 260, 800, 520);
            Gui.PanelBox(r);
            Gui.Label(new Rect(r.x + 28, r.y + 14, r.width - 56, 44), "SCENARIO B  -  Residential Water Leakage", Gui.Heading, Gui.Accent);
            string text =
                "A resident has water coming out of a kitchen wall somewhere in the tower.\n\n" +
                "1  Initial conditions - find the resident (the red ! marks them) using the lift.\n" +
                "2  Report - talk to the resident (E) or press Report Water Leakage. The response timer starts.\n" +
                "3  Investigation - a plumber travels to the apartment. Inspect the water, the sink and the heater; the real source is behind the wall access panel.\n" +
                "4  Repair - close the red shut-off valve, then repair the joint while the plumber is on site.\n" +
                "5  Results - investigation time, repair time, status.\n\n" +
                "The apartment is chosen at random each run. Use the lift panels (E) and the on-screen Go to incident button once the leak is reported.";
            Gui.Label(new Rect(r.x + 28, r.y + 62, r.width - 56, 340), text, Gui.BodyWrap);
            if (Gui.BtnBig(new Rect(r.x + 28, r.y + 430, 300, 60), "Start Scenario")) StartScenario();
            if (Gui.Btn(new Rect(r.x + r.width - 228, r.y + 438, 200, 44), "Main menu")) HudController.GoMenu();
        }

        string StageMark(int stage)
        {
            int cur;
            switch (Model.Phase)
            {
                case LeakPhase.Initial: cur = 1; break;
                case LeakPhase.Reported: cur = 3; break;
                case LeakPhase.Located: cur = 4; break;
                default: cur = 5; break;
            }
            if (Model.Phase == LeakPhase.Reported && !Model.PlumberOnSite) cur = 2;
            if (stage < cur || Model.Phase == LeakPhase.Repaired) return "<color=#4dd96f>[done]</color> ";
            if (stage == cur) return "<color=#ffa31f>[now]</color> ";
            return "<color=#8a93a6>[ ]</color> ";
        }

        void DrawStatus(float W, float H)
        {
            var p = new Rect(14, 48, 350, 470);
            Gui.PanelBox(p);
            float y = p.y + 8;
            Gui.Label(new Rect(p.x + 12, y, p.width - 24, 26), "Incident: Water leakage", Gui.Body, Gui.Accent); y += 28;
            string[] stages = { "Initial conditions", "Report filed", "Investigation", "Repair", "Results" };
            for (int i = 0; i < 5; i++)
            {
                Gui.Label(new Rect(p.x + 12, y, p.width - 24, 22), StageMark(i + 1) + (i + 1) + ". " + stages[i], Gui.Small);
                y += 22;
            }
            y += 6;
            bool reported = Model.Phase != LeakPhase.Initial;
            Gui.Label(new Rect(p.x + 12, y, p.width - 24, 22), "Status: " + Model.StatusText, Gui.Body); y += 28;
            Gui.Label(new Rect(p.x + 12, y, p.width - 24, 22), "Response timer: " + (reported ? Fmt.Time(Model.SinceReport) : "not started"), Gui.Small); y += 22;
            Gui.Label(new Rect(p.x + 12, y, p.width - 24, 40), "Report location: " + (reported ? LocationText : "-"), Gui.Small); y += 42;
            Gui.Label(new Rect(p.x + 12, y, p.width - 24, 22), "Plumber: " + PlumberText, Gui.Small); y += 22;
            Gui.Label(new Rect(p.x + 12, y, p.width - 24, 22), "Source located: " + (Model.Located ? "<color=#4dd96f>yes</color>" : "no") + "    Valve: " + (Model.ValveClosed ? "closed" : "open"), Gui.Small); y += 22;
            Gui.Label(new Rect(p.x + 12, y, p.width - 24, 22), "Wrong inspections: " + Model.WrongInspections + "    Water spilled: " + Model.SpilledLitres.ToString("0") + " L", Gui.Small); y += 26;
            if (repairing) { Gui.Label(new Rect(p.x + 12, y, p.width - 24, 20), "Repair progress", Gui.Small); y += 20; Gui.Progress(new Rect(p.x + 12, y, p.width - 24, 16), repairProgress, Gui.Good); y += 24; }

            if (Model.Phase == LeakPhase.Initial)
            {
                if (Gui.BtnBig(new Rect(p.x + 12, y, p.width - 24, 48), "Report Water Leakage")) Report();
                y += 56;
            }
            else
            {
                if (Gui.Btn(new Rect(p.x + 12, y, p.width - 24, 34), "Go to incident (apartment door)"))
                {
                    Vector3 d = Layout.AptDoor(Model.Floor, Model.Apt);
                    if (player != null) player.Teleport(new Vector3(d.x, y0 + 0.05f, Layout.CorridorMid), Layout.AptSide(Model.Apt) == 0 ? 180f : 0f);
                    hud.Toast("At " + Layout.AptName(Model.Floor, Model.Apt) + ". Step inside and inspect the wet area.");
                }
                y += 40;
            }
            if (Gui.Btn(new Rect(p.x + 12, y, p.width - 24, 32), resultsOpen ? "Hide results" : "Show results"))
            { if (Model.Finished) resultsOpen = !resultsOpen; else hud.Toast("Results appear when the incident is resolved."); }

            string banner = Model.Phase == LeakPhase.Initial ? "Find the resident and report the leak" :
                            (Model.Finished ? (Model.Stopped ? "Leak repaired" : "Incident unresolved") : "Water leak - response in progress");
            var br = new Rect(W * 0.5f - 300, 44, 600, 32);
            Gui.PanelBox(br);
            Gui.Label(br, banner, Gui.Center, Model.Stopped ? Gui.Good : Gui.Accent);
        }

        void DrawResults(float W, float H)
        {
            Gui.DimScreen(0.55f);
            var r = new Rect(W * 0.5f - 340, H * 0.5f - 250, 680, 500);
            Gui.PanelBox(r);
            Gui.Label(new Rect(r.x + 28, r.y + 14, r.width - 56, 40), "WATER LEAK RESULTS", Gui.Heading, Gui.Accent);
            string lines =
                "Incident status:  " + (Model.Stopped ? "<color=#4dd96f>Repaired</color>" : "<color=#ff6b5a>" + Model.StatusText + "</color>") + "\n\n" +
                "Leak located:  " + (Model.Located ? "yes" : "no") + "\n" +
                "Leak stopped:  " + (Model.Stopped ? "yes" : "no") + "\n" +
                "Time from report to investigation (source found):  " + Fmt.Time(Model.TimeToInvestigate) + "\n" +
                "Time taken to repair:  " + Fmt.Time(Model.TimeToRepair) + "\n" +
                "Wrong inspections:  " + Model.WrongInspections + "\n" +
                "Water spilled:  " + Model.SpilledLitres.ToString("0") + " L (simulated)\n\n" +
                "Result saved to your training history.";
            Gui.Label(new Rect(r.x + 28, r.y + 62, r.width - 56, 300), lines, Gui.BodyWrap);
            if (Gui.BtnBig(new Rect(r.x + 28, r.y + 410, 190, 56), "Restart")) HudController.Restart();
            if (Gui.Btn(new Rect(r.x + 232, r.y + 418, 200, 44), "Main menu")) HudController.GoMenu();
            if (Gui.Btn(new Rect(r.x + 446, r.y + 418, 200, 44), "Keep exploring")) resultsOpen = false;
        }
    }
}
