using UnityEngine;
using UnityEngine.SceneManagement;

namespace UrbanSim
{
    /// <summary>Shared in-scene HUD: title bar, pause menu, lift selector, interaction prompt, toasts, speed buttons.</summary>
    public class HudController : MonoBehaviour
    {
        public static HudController Instance;
        public string ModeTitle = "Free Exploration";
        public bool ShowSpeedButtons;
        public string InteractHint;

        string toast; float toastUntil;
        bool liftOpen; int liftFrom;
        bool showHelp;
        PlayerController player;

        public void Init(PlayerController p)
        {
            player = p;
            Instance = this;
            GameState.LiftRequested = OpenLift;
        }

        void OnDestroy() { if (Instance == this) Instance = null; }

        public void Toast(string msg, float seconds = 4f)
        {
            toast = msg; toastUntil = Time.unscaledTime + seconds;
        }

        void OpenLift(int from)
        {
            liftOpen = true; liftFrom = from; GameState.Modal = true;
        }

        void CloseLift()
        {
            liftOpen = false;
            GameState.Modal = Scenario != null && Scenario.ModalOpen;
        }

        /// <summary>Scenario scripts expose whether their briefing/results dialog is open.</summary>
        public IModalSource Scenario;

        void Update()
        {
            if (Input.GetKeyDown(KeyCode.Escape))
            {
                if (liftOpen) CloseLift();
                else GameState.Paused = !GameState.Paused;
            }
            if (Input.GetKeyDown(KeyCode.Tab) && !GameState.Paused) GameState.FreeCursor = !GameState.FreeCursor;
            if (!liftOpen) GameState.Modal = Scenario != null && Scenario.ModalOpen;
            Time.timeScale = GameState.Paused ? 0f : GameState.SimSpeed;
        }

        void OnGUI()
        {
            Gui.Begin();
            float W = Gui.W, H = Gui.H;

            // top bar
            Gui.PanelBox(new Rect(0, 0, W, 40));
            Gui.Label(new Rect(14, 0, 420, 40), "<b>URBANSIM 3D</b>  |  " + ModeTitle, Gui.Body, Gui.Accent);
            if (player != null)
                Gui.Label(new Rect(W - 560, 0, 200, 40), "Floor: " + Layout.FloorName(player.CurrentFloor), Gui.Body);

            // quick buttons (usable when the cursor is free - press TAB)
            float bx = W - 350, by = 4;
            if (Gui.Btn(new Rect(bx, by, 80, 32), "Interact") && player != null) player.TryInteract();
            if (Gui.Btn(new Rect(bx + 86, by, 70, 32), "Pause")) GameState.Paused = true;
            if (Gui.Btn(new Rect(bx + 162, by, 88, 32), "Restart")) Restart();
            if (Gui.Btn(new Rect(bx + 256, by, 84, 32), "Menu")) GoMenu();

            if (ShowSpeedButtons)
            {
                Gui.Label(new Rect(W - 340, 44, 90, 26), "Sim speed", Gui.Small);
                int[] sp = { 1, 2, 4 };
                for (int i = 0; i < sp.Length; i++)
                    if (Gui.BtnSelected(new Rect(W - 250 + i * 52, 44, 48, 26), sp[i] + "x", GameState.SimSpeed == sp[i])) GameState.SimSpeed = sp[i];
            }

            // crosshair and prompt
            if (!GameState.CursorFree) Gui.Fill(new Rect(W * 0.5f - 2, H * 0.5f - 2, 4, 4), new Color(1f, 1f, 1f, 0.85f));
            if (player != null && player.Focus != null && !GameState.CursorFree)
            {
                string label = "[E]  " + player.Focus.CurrentLabel;
                var r = new Rect(W * 0.5f - 220, H * 0.5f + 40, 440, 34);
                Gui.PanelBox(r);
                Gui.Label(r, label, Gui.Center);
            }

            // bottom hint
            string free = GameState.FreeCursor ? "TAB: back to mouse-look" : "TAB: free cursor for buttons";
            Gui.Label(new Rect(14, H - 28, W - 28, 24), "WASD move  |  Mouse look  |  Shift run  |  Wheel zoom  |  E interact  |  Esc pause  |  " + free, Gui.Small);

            if (!string.IsNullOrEmpty(toast) && Time.unscaledTime < toastUntil)
            {
                var r = new Rect(W * 0.5f - 330, 80, 660, 56);
                Gui.PanelBox(r);
                Gui.Label(r, toast, Gui.Center);
            }

            if (liftOpen) DrawLift(W, H);
            if (GameState.Paused) DrawPause(W, H);
            Gui.End();
        }

        void DrawLift(float W, float H)
        {
            Gui.DimScreen(0.45f);
            var r = new Rect(W * 0.5f - 270, H * 0.5f - 230, 540, 460);
            Gui.PanelBox(r);
            Gui.Label(new Rect(r.x + 20, r.y + 10, r.width - 40, 40), "Lift - select floor", Gui.Heading);
            Gui.Label(new Rect(r.x + 20, r.y + 48, r.width - 40, 24), "You are on floor " + Layout.FloorName(liftFrom) + ". Stairs are in both end cores.", Gui.Small);
            for (int f = 0; f < Layout.Floors; f++)
            {
                int row = (Layout.Floors - 1 - f) / 4;
                int col = (Layout.Floors - 1 - f) % 4;
                var br = new Rect(r.x + 30 + col * 122, r.y + 84 + row * 54, 112, 46);
                if (Gui.BtnSelected(br, "Floor " + Layout.FloorName(f), f == liftFrom))
                {
                    if (player != null) player.Teleport(Layout.LiftArrival(f) + new Vector3(0f, 0.05f, -0.2f), 0f);
                    CloseLift();
                    Toast("Arrived on floor " + Layout.FloorName(f));
                }
            }
            if (Gui.Btn(new Rect(r.x + r.width - 150, r.y + r.height - 50, 130, 38), "Cancel")) CloseLift();
        }

        void DrawPause(float W, float H)
        {
            Gui.DimScreen(0.6f);
            var r = new Rect(W * 0.5f - 300, H * 0.5f - 270, 600, 540);
            Gui.PanelBox(r);
            Gui.Label(new Rect(r.x + 24, r.y + 12, r.width - 48, 44), "PAUSED", Gui.Heading);
            float y = r.y + 64;
            if (Gui.BtnBig(new Rect(r.x + 40, y, r.width - 80, 52), "Resume")) GameState.Paused = false;
            y += 62;
            if (Gui.Btn(new Rect(r.x + 40, y, r.width - 80, 42), "Restart scenario")) Restart();
            y += 50;
            if (GameState.Current != null)
            {
                if (Gui.Btn(new Rect(r.x + 40, y, r.width - 80, 42), "End scenario and show results"))
                {
                    GameState.Paused = false;
                    GameState.Current.EndNow();
                }
                y += 50;
            }
            if (Gui.Btn(new Rect(r.x + 40, y, r.width - 80, 42), "Return to main menu")) GoMenu();
            y += 56;
            string help =
                "<b>Controls</b>\n" +
                "W / A / S / D  -  move      Mouse  -  look\n" +
                "Shift  -  run      Mouse wheel  -  zoom\n" +
                "E  -  interact      Esc  -  pause / resume\n" +
                "Tab  -  free the cursor to click on-screen buttons\n" +
                "Lifts: look at the dark panel beside a lift door and press E.\n" +
                "Stairs: two stair cores at the west and east ends of every floor.";
            Gui.Label(new Rect(r.x + 40, y, r.width - 80, 150), help, Gui.BodyWrap);
        }

        public static void Restart()
        {
            GameState.Paused = false;
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }

        public static void GoMenu()
        {
            GameState.Paused = false;
            SceneManager.LoadScene("MainMenu");
        }
    }

    public interface IModalSource
    {
        bool ModalOpen { get; }
    }
}
