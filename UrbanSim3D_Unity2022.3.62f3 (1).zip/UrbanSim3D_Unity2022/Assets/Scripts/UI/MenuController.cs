using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace UrbanSim
{
    /// <summary>Main menu: scenario cards, start, instructions, training history and analytics.</summary>
    public class MenuController : MonoBehaviour
    {
        enum Tab { Instructions, History, Analytics }
        Tab tab = Tab.Instructions;
        List<TrainingRecord> history = new List<TrainingRecord>();
        AnalyticsSummary stats = new AnalyticsSummary();

        void Start() { Reload(); }

        void Reload()
        {
            history = SaveSystem.Load().records;
            stats = AnalyticsSummary.From(history);
        }

        void OnGUI()
        {
            Gui.Begin();
            float W = Gui.W, H = Gui.H;
            Gui.Fill(new Rect(0, 0, 500, H), new Color(0.03f, 0.05f, 0.1f, 0.75f));
            Gui.Label(new Rect(50, 28, 440, 70), "URBANSIM 3D", Gui.Title, Color.white);
            Gui.Label(new Rect(52, 92, 440, 26), "Residential emergency-response training", Gui.Body, Gui.Accent);

            DrawCard(new Rect(50, 140, 400, 120), ScenarioKind.Fire, "Fire Emergency",
                "Fire, smoke and alarm in a 20-storey tower. Watch sprinklers act and track the evacuation.");
            DrawCard(new Rect(50, 270, 400, 120), ScenarioKind.Leak, "Water Leakage",
                "Report a leak, guide the plumber, find the hidden source and stop it.");

            if (Gui.BtnBig(new Rect(50, 410, 400, 58), "Start Training"))
                SceneManager.LoadScene(GameState.Selected == ScenarioKind.Fire ? "FireEmergency" : "WaterLeakage");
            if (Gui.Btn(new Rect(50, 478, 400, 40), "Explore the Building")) SceneManager.LoadScene("BuildingEnvironment");

            if (Gui.BtnSelected(new Rect(50, 530, 126, 38), "Instructions", tab == Tab.Instructions)) tab = Tab.Instructions;
            if (Gui.BtnSelected(new Rect(182, 530, 126, 38), "History", tab == Tab.History)) { tab = Tab.History; Reload(); }
            if (Gui.BtnSelected(new Rect(314, 530, 136, 38), "Analytics", tab == Tab.Analytics)) { tab = Tab.Analytics; Reload(); }
            if (Gui.Btn(new Rect(50, 580, 400, 36), "Quit"))
            {
#if UNITY_EDITOR
                UnityEditor.EditorApplication.isPlaying = false;
#else
                Application.Quit();
#endif
            }
            Gui.Label(new Rect(50, H - 40, 440, 24), "Training simulation - not a certified safety model.", Gui.Small);

            var p = new Rect(530, 40, W - 570, H - 80);
            Gui.PanelBox(p);
            switch (tab)
            {
                case Tab.Instructions: DrawInstructions(p); break;
                case Tab.History: DrawHistory(p); break;
                default: DrawAnalytics(p); break;
            }
            Gui.End();
        }

        void DrawCard(Rect r, ScenarioKind kind, string title, string desc)
        {
            bool sel = GameState.Selected == kind;
            Gui.Fill(new Rect(r.x - 4, r.y - 4, r.width + 8, r.height + 8), sel ? Gui.Accent : new Color(0.3f, 0.36f, 0.5f, 0.8f));
            Gui.PanelBox(r);
            Gui.Label(new Rect(r.x + 14, r.y + 8, r.width - 28, 30), title, Gui.Heading, sel ? Gui.Accent : Color.white);
            Gui.Label(new Rect(r.x + 14, r.y + 40, r.width - 28, 70), desc, Gui.BodyWrap);
            if (GUI.Button(r, GUIContent.none, GUIStyle.none)) GameState.Selected = kind;
        }

        void DrawInstructions(Rect p)
        {
            Gui.Label(new Rect(p.x + 24, p.y + 14, p.width - 48, 36), "How to use UrbanSim 3D", Gui.Heading, Gui.Accent);
            string t =
                "<b>1.</b> Select a scenario card and press <b>Start Training</b>.\n" +
                "<b>2.</b> Read the briefing, then press <b>Start Scenario</b>.\n" +
                "<b>3.</b> Move around the tower, use the lifts to reach any floor, and complete the objectives.\n" +
                "<b>4.</b> A results screen appears at the end and is saved to History and Analytics.\n\n" +
                "<b>Controls</b>\n" +
                "W / A / S / D  -  move forward / left / backward / right\n" +
                "Mouse  -  look around        Mouse wheel  -  zoom in / out\n" +
                "Shift  -  run        E  -  interact with objects, panels and people\n" +
                "Esc  -  pause menu        Tab  -  free the cursor to click on-screen buttons\n\n" +
                "<b>Lifts</b>: look at the dark panel beside the lift doors and press E.\n" +
                "<b>Stairs</b>: two stair cores, at the west and east ends of each floor.\n\n" +
                "<b>Fire Emergency</b>: watch the alarm, sprinklers and evacuation. Sprinklers reduce flames but smoke still makes areas unsafe.\n" +
                "<b>Water Leakage</b>: report the leak, let the plumber arrive, inspect the wet area, open the wall access panel, close the valve and repair the joint.";
            Gui.Label(new Rect(p.x + 24, p.y + 56, p.width - 48, p.height - 70), t, Gui.BodyWrap);
        }

        void DrawHistory(Rect p)
        {
            Gui.Label(new Rect(p.x + 24, p.y + 14, p.width - 48, 36), "Training history (" + history.Count + " runs)", Gui.Heading, Gui.Accent);
            if (history.Count == 0)
            {
                Gui.Label(new Rect(p.x + 24, p.y + 70, p.width - 48, 60), "No training runs recorded yet. Complete a scenario to see results here.", Gui.BodyWrap);
                return;
            }
            float y = p.y + 60;
            int shown = 0;
            for (int i = history.Count - 1; i >= 0 && shown < 14; i--, shown++)
            {
                TrainingRecord r = history[i];
                string line;
                if (r.scenario == "Fire")
                    line = r.timestamp + "   FIRE   " + r.evacuated + "/" + r.totalResidents + " out   " + Fmt.Time(r.durationSeconds) + "   " + (r.completed ? "<color=#4dd96f>complete</color>" : "<color=#ffa31f>incomplete</color>");
                else
                    line = r.timestamp + "   LEAK   found " + (r.leakLocated ? Fmt.Time(r.timeToInvestigate) : "no") + "   repaired " + (r.leakStopped ? Fmt.Time(r.timeToRepair) : "no") + "   " + (r.leakStopped ? "<color=#4dd96f>complete</color>" : "<color=#ffa31f>incomplete</color>");
                Gui.Label(new Rect(p.x + 24, y, p.width - 48, 26), line, Gui.Body);
                y += 28;
            }
            if (Gui.Btn(new Rect(p.x + p.width - 200, p.y + p.height - 54, 176, 38), "Clear history")) { SaveSystem.Clear(); Reload(); }
        }

        void DrawAnalytics(Rect p)
        {
            Gui.Label(new Rect(p.x + 24, p.y + 14, p.width - 48, 36), "Performance analytics", Gui.Heading, Gui.Accent);
            if (stats.TotalRuns == 0)
            {
                Gui.Label(new Rect(p.x + 24, p.y + 70, p.width - 48, 60), "No data yet. Analytics are calculated from your recorded runs only.", Gui.BodyWrap);
                return;
            }
            string t =
                "<b>Total runs:</b> " + stats.TotalRuns + "\n\n" +
                "<b>Fire Emergency</b>\n" +
                "Runs: " + stats.FireRuns + "   Fully evacuated: " + stats.FireCompleted + "\n" +
                "Average residents evacuated: " + stats.FireAvgEvacPercent.ToString("0") + "%\n" +
                "Average duration: " + Fmt.Time(stats.FireAvgDuration) + "\n" +
                "Best full-evacuation time: " + Fmt.Time(stats.FireBestDuration) + "\n\n" +
                "<b>Water Leakage</b>\n" +
                "Runs: " + stats.LeakRuns + "   Repaired: " + stats.LeakRepaired + "\n" +
                "Average time to locate source: " + (stats.LeakRuns > 0 ? Fmt.Time(stats.LeakAvgInvestigate) : "--:--") + "\n" +
                "Average time to repair: " + (stats.LeakRepaired > 0 ? Fmt.Time(stats.LeakAvgRepair) : "--:--");
            Gui.Label(new Rect(p.x + 24, p.y + 60, p.width - 48, 330), t, Gui.BodyWrap);
            float by = p.y + p.height - 130;
            if (stats.FireRuns > 0) { Gui.Label(new Rect(p.x + 24, by, 260, 22), "Evacuation success (avg)", Gui.Small); Gui.Progress(new Rect(p.x + 24, by + 24, p.width - 48, 16), stats.FireAvgEvacPercent / 100f, Gui.Good); }
            if (stats.LeakRuns > 0) { Gui.Label(new Rect(p.x + 24, by + 46, 260, 22), "Leaks repaired", Gui.Small); Gui.Progress(new Rect(p.x + 24, by + 70, p.width - 48, 16), (float)stats.LeakRepaired / stats.LeakRuns, Gui.Accent); }
        }
    }
}
