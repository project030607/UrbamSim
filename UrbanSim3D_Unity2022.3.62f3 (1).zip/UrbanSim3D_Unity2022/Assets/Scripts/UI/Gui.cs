using UnityEngine;

namespace UrbanSim
{
    /// <summary>Small IMGUI toolkit. Layout is authored for a 720-unit-high virtual screen and scaled to the window.</summary>
    public static class Gui
    {
        public static GUIStyle Title, Heading, Body, BodyWrap, Small, Button, ButtonSel, ButtonBig, Panel, Center, CenterBig;
        static Texture2D bgPanel, btn, btnHover, btnActive, btnSel, btnBigN, btnBigH;
        static bool ready;

        public static float Scale { get { return Mathf.Max(0.5f, Screen.height / 720f); } }
        public static float W { get { return Screen.width / Scale; } }
        public static float H { get { return Screen.height / Scale; } }

        public static readonly Color Accent = new Color(0.98f, 0.62f, 0.12f);
        public static readonly Color Good = new Color(0.3f, 0.85f, 0.45f);
        public static readonly Color Bad = new Color(0.95f, 0.3f, 0.25f);
        public static readonly Color Dim = new Color(0.75f, 0.8f, 0.88f);

        static Texture2D Solid(Color c)
        {
            var t = new Texture2D(1, 1, TextureFormat.RGBA32, false);
            t.SetPixel(0, 0, c);
            t.Apply();
            t.hideFlags = HideFlags.HideAndDontSave;
            return t;
        }

        static GUIStyle MakeStyle(int size, FontStyle fs, Color col, TextAnchor anchor, bool wrap)
        {
            var s = new GUIStyle();
            s.fontSize = size; s.fontStyle = fs; s.alignment = anchor; s.wordWrap = wrap;
            s.normal.textColor = col;
            s.richText = true;
            return s;
        }

        static void Init()
        {
            if (ready && bgPanel != null) return;
            bgPanel = Solid(new Color(0.06f, 0.09f, 0.15f, 0.88f));
            btn = Solid(new Color(0.16f, 0.32f, 0.58f, 0.95f));
            btnHover = Solid(new Color(0.24f, 0.45f, 0.78f, 1f));
            btnActive = Solid(new Color(0.1f, 0.2f, 0.4f, 1f));
            btnSel = Solid(new Color(0.85f, 0.5f, 0.1f, 1f));
            btnBigN = Solid(new Color(0.9f, 0.45f, 0.08f, 1f));
            btnBigH = Solid(new Color(1f, 0.58f, 0.18f, 1f));

            Title = MakeStyle(56, FontStyle.Bold, Color.white, TextAnchor.MiddleLeft, false);
            Heading = MakeStyle(26, FontStyle.Bold, Color.white, TextAnchor.MiddleLeft, false);
            Body = MakeStyle(18, FontStyle.Normal, Color.white, TextAnchor.MiddleLeft, false);
            BodyWrap = MakeStyle(18, FontStyle.Normal, Color.white, TextAnchor.UpperLeft, true);
            Small = MakeStyle(14, FontStyle.Normal, new Color(0.85f, 0.9f, 1f), TextAnchor.MiddleLeft, false);
            Center = MakeStyle(18, FontStyle.Normal, Color.white, TextAnchor.MiddleCenter, true);
            CenterBig = MakeStyle(30, FontStyle.Bold, Color.white, TextAnchor.MiddleCenter, true);

            Panel = new GUIStyle();
            Panel.normal.background = bgPanel;
            Panel.border = new RectOffset(2, 2, 2, 2);

            Button = new GUIStyle();
            Button.fontSize = 17; Button.fontStyle = FontStyle.Bold; Button.alignment = TextAnchor.MiddleCenter;
            Button.normal.textColor = Color.white; Button.hover.textColor = Color.white; Button.active.textColor = Color.white;
            Button.normal.background = btn; Button.hover.background = btnHover; Button.active.background = btnActive;
            Button.wordWrap = true;

            ButtonSel = new GUIStyle(Button);
            ButtonSel.normal.background = btnSel; ButtonSel.hover.background = btnSel;

            ButtonBig = new GUIStyle(Button);
            ButtonBig.fontSize = 24;
            ButtonBig.normal.background = btnBigN; ButtonBig.hover.background = btnBigH; ButtonBig.active.background = btnActive;
            ready = true;
        }

        public static void Begin()
        {
            Init();
            float s = Scale;
            GUI.matrix = Matrix4x4.TRS(Vector3.zero, Quaternion.identity, new Vector3(s, s, 1f));
        }

        public static void End() { GUI.matrix = Matrix4x4.identity; }

        public static void Fill(Rect r, Color c)
        {
            Color old = GUI.color;
            GUI.color = c;
            GUI.DrawTexture(r, Texture2D.whiteTexture);
            GUI.color = old;
        }

        public static void PanelBox(Rect r) { GUI.Box(r, GUIContent.none, Panel); }

        public static void Label(Rect r, string text, GUIStyle style, Color c)
        {
            Color old = style.normal.textColor;
            style.normal.textColor = c;
            GUI.Label(r, text, style);
            style.normal.textColor = old;
        }

        public static void Label(Rect r, string text, GUIStyle style) { GUI.Label(r, text, style); }

        public static bool Btn(Rect r, string text) { return GUI.Button(r, text, Button); }
        public static bool BtnSelected(Rect r, string text, bool selected) { return GUI.Button(r, text, selected ? ButtonSel : Button); }
        public static bool BtnBig(Rect r, string text) { return GUI.Button(r, text, ButtonBig); }

        public static void Progress(Rect r, float v, Color c)
        {
            Fill(r, new Color(0f, 0f, 0f, 0.5f));
            Fill(new Rect(r.x + 1, r.y + 1, Mathf.Max(0f, (r.width - 2f) * Mathf.Clamp01(v)), r.height - 2f), c);
        }

        public static void DimScreen(float alpha)
        {
            Fill(new Rect(0, 0, W, H), new Color(0f, 0f, 0f, alpha));
        }
    }
}
