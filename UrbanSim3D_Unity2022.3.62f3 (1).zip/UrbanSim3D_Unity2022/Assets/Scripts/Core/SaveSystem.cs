using System;
using System.IO;
using UnityEngine;

namespace UrbanSim
{
    /// <summary>Local JSON persistence of real training results (Application.persistentDataPath).</summary>
    public static class SaveSystem
    {
        /// <summary>Tests can redirect storage to a temp file.</summary>
        public static string PathOverride;

        static string FilePath
        {
            get { return PathOverride ?? Path.Combine(Application.persistentDataPath, "urbansim_history.json"); }
        }

        public static TrainingHistory Load()
        {
            try
            {
                if (!File.Exists(FilePath)) return new TrainingHistory();
                string json = File.ReadAllText(FilePath);
                TrainingHistory h = JsonUtility.FromJson<TrainingHistory>(json);
                if (h == null || h.records == null) return new TrainingHistory();
                return h;
            }
            catch (Exception e)
            {
                Debug.LogWarning("UrbanSim: could not read history: " + e.Message);
                return new TrainingHistory();
            }
        }

        public static void Append(TrainingRecord record)
        {
            if (record == null) return;
            try
            {
                TrainingHistory h = Load();
                h.records.Add(record);
                string dir = Path.GetDirectoryName(FilePath);
                if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir)) Directory.CreateDirectory(dir);
                File.WriteAllText(FilePath, JsonUtility.ToJson(h, true));
            }
            catch (Exception e)
            {
                Debug.LogWarning("UrbanSim: could not save history: " + e.Message);
            }
        }

        public static void Clear()
        {
            try { if (File.Exists(FilePath)) File.Delete(FilePath); }
            catch (Exception e) { Debug.LogWarning("UrbanSim: could not clear history: " + e.Message); }
        }
    }
}
