using System;
using System.Collections.Generic;
using UnityEngine;

namespace UrbanSim
{
    public enum ScenarioKind { Fire = 0, Leak = 1 }

    /// <summary>One completed (or abandoned) training run. Stored as JSON.</summary>
    [Serializable]
    public class TrainingRecord
    {
        public string scenario;          // "Fire" or "Leak"
        public string timestamp;
        public float durationSeconds;
        public bool completed;
        public string status;
        // fire
        public int totalResidents;
        public int evacuated;
        public int remaining;
        public float exposureSeconds;
        public int exposedResidents;
        public string routeSafety;
        // leak
        public float timeToInvestigate;
        public float timeToRepair;
        public bool leakLocated;
        public bool leakStopped;
        public int wrongInspections;
    }

    [Serializable]
    public class TrainingHistory
    {
        public List<TrainingRecord> records = new List<TrainingRecord>();
    }

    public class AnalyticsSummary
    {
        public int FireRuns, FireCompleted;
        public float FireAvgEvacPercent, FireAvgDuration, FireBestDuration = -1f;
        public int LeakRuns, LeakRepaired;
        public float LeakAvgInvestigate, LeakAvgRepair;
        public int TotalRuns { get { return FireRuns + LeakRuns; } }

        public static AnalyticsSummary From(IList<TrainingRecord> list)
        {
            var a = new AnalyticsSummary();
            if (list == null) return a;
            float evacPct = 0f, fireDur = 0f, inv = 0f, rep = 0f;
            int invN = 0, repN = 0;
            for (int i = 0; i < list.Count; i++)
            {
                TrainingRecord r = list[i];
                if (r == null) continue;
                if (r.scenario == "Fire")
                {
                    a.FireRuns++;
                    if (r.completed) a.FireCompleted++;
                    evacPct += r.totalResidents > 0 ? 100f * r.evacuated / r.totalResidents : 0f;
                    fireDur += r.durationSeconds;
                    if (r.completed && (a.FireBestDuration < 0f || r.durationSeconds < a.FireBestDuration))
                        a.FireBestDuration = r.durationSeconds;
                }
                else if (r.scenario == "Leak")
                {
                    a.LeakRuns++;
                    if (r.leakStopped) a.LeakRepaired++;
                    if (r.leakLocated) { inv += r.timeToInvestigate; invN++; }
                    if (r.leakStopped) { rep += r.timeToRepair; repN++; }
                }
            }
            if (a.FireRuns > 0) { a.FireAvgEvacPercent = evacPct / a.FireRuns; a.FireAvgDuration = fireDur / a.FireRuns; }
            if (invN > 0) a.LeakAvgInvestigate = inv / invN;
            if (repN > 0) a.LeakAvgRepair = rep / repN;
            return a;
        }
    }

    public static class Fmt
    {
        public static string Time(float seconds)
        {
            if (seconds < 0f) return "--:--";
            int s = Mathf.RoundToInt(seconds);
            return (s / 60).ToString("00") + ":" + (s % 60).ToString("00");
        }
    }
}
