using System.Collections.Generic;
using UnityEngine;

namespace UrbanSim
{
    /// <summary>Pure geometry description of the tower. Everything is generated from these numbers.</summary>
    public static class Layout
    {
        public const int Floors = 20;               // floor index 0 (ground) .. 19
        public const float FloorHeight = 3.2f;
        public const float Length = 24f;            // X extent of the main block
        public const float Depth = 12f;             // Z extent of the main block
        public const float CorridorZ0 = 5f;
        public const float CorridorZ1 = 7f;
        public const float CorridorMid = 6f;
        public const int AptCols = 4;
        public const float AptWidth = 6f;
        public const float CoreZ0 = 4.5f;           // stair cores sit at the two short ends
        public const float CoreZ1 = 7.5f;
        public const float CoreDepth = 6f;
        public const float NearLanding = 1.2f;
        public const float RampEnd = 4.0f;
        public const float RampRise = 1.6f;
        public const float LiftX = 12f;

        public static float FloorY(int f) { return f * FloorHeight; }

        public static int FloorAt(float y)
        {
            int f = Mathf.FloorToInt((y + 0.3f) / FloorHeight);
            return Mathf.Clamp(f, 0, Floors - 1);
        }

        public static string FloorName(int f) { return f == 0 ? "G" : f.ToString(); }
        public static int AptSide(int apt) { return apt / AptCols; }      // 0 = south (front), 1 = north (back)
        public static int AptCol(int apt) { return apt % AptCols; }
        public static string AptName(int floor, int apt) { return "Apt " + FloorName(floor) + (char)('A' + apt); }
        public static bool AptExists(int floor, int apt) { return !(floor == 0 && AptSide(apt) == 0); }
        public static float AptX(int apt) { return AptCol(apt) * AptWidth + AptWidth * 0.5f; }
        public static float AptZ(int apt) { return AptSide(apt) == 0 ? 2.5f : 9.5f; }
        public static Vector3 AptCenter(int floor, int apt) { return new Vector3(AptX(apt), FloorY(floor), AptZ(apt)); }
        public static Vector3 AptDoor(int floor, int apt) { return new Vector3(AptX(apt), FloorY(floor), AptSide(apt) == 0 ? 5f : 7f); }
        public static Vector3 LiftArrival(int floor) { return new Vector3(LiftX, FloorY(floor), CorridorMid); }

        /// <summary>Core 0 = west end (x &lt; 0), core 1 = east end (x &gt; 24).</summary>
        public static float CoreX(int core) { return core == 0 ? 0f : Length; }

        public static Vector3 CorePoint(int core, float u, float v, float y)
        {
            float x = core == 0 ? -u : Length + u;
            return new Vector3(x, y, CoreZ0 + v);
        }

        /// <summary>Waypoints that take a walker from the near landing of fromFloor to the near landing of fromFloor-1.</summary>
        public static List<Vector3> StairDescent(int core, int fromFloor)
        {
            float top = FloorY(fromFloor);
            float bottom = FloorY(fromFloor - 1);
            float mid = bottom + RampRise;
            var p = new List<Vector3>();
            p.Add(CorePoint(core, NearLanding, 2.25f, top));
            p.Add(CorePoint(core, RampEnd, 2.25f, mid));
            p.Add(CorePoint(core, 4.8f, 1.5f, mid));
            p.Add(CorePoint(core, RampEnd, 0.75f, mid));
            p.Add(CorePoint(core, NearLanding, 0.75f, bottom));
            p.Add(CorePoint(core, 0.6f, 1.5f, bottom));
            return p;
        }

        public static Vector3 AssemblyPoint(int core, int slot)
        {
            float baseX = core == 0 ? -16f : Length + 16f;
            int row = slot / 5;
            int col = slot % 5;
            return new Vector3(baseX + (col - 2) * 1.5f + (core == 0 ? -row * 0.4f : row * 0.4f), 0f, 2f - row * 1.6f);
        }
    }
}
