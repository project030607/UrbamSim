using System;
using System.Collections.Generic;
using UnityEngine;

namespace UrbanSim
{
    public enum FirePhase { Briefing = 0, Normal = 1, FireStarted = 2, Sprinklers = 3, Evacuation = 4, Complete = 5 }

    public class RouteChoice
    {
        public int Core;          // 0 = west stair, 1 = east stair
        public float Cost;
        public bool Penalized;    // route had to be chosen despite a predicted hazard
    }

    /// <summary>Pure state machine for the fire scenario (no scene objects), so it can be unit-tested.</summary>
    public class FireModel
    {
        // configuration
        public int FireFloor = 7;
        public int FireApt = 1;
        public bool FireInCorridor = false;
        public float NormalDuration = 6f;
        public float SprinklerDelay = 7f;
        public float TimeLimit = 420f;

        // state
        public FirePhase Phase = FirePhase.Briefing;
        public float Elapsed;
        public float SinceIgnition;
        public float FireIntensity;      // 0..1
        public float SmokeLevel;         // 0..1
        public bool AlarmOn;
        public bool SprinklersActive;
        public bool TimedOut;
        public int TotalResidents;
        public int Evacuated;
        public float ExposureSeconds;    // resident-seconds spent in hazard zones
        public float PlayerExposureSeconds;
        readonly HashSet<int> exposed = new HashSet<int>();

        public int ExposedResidents { get { return exposed.Count; } }
        public int Remaining { get { return Math.Max(0, TotalResidents - Evacuated); } }
        public bool IsActive { get { return Phase != FirePhase.Briefing && Phase != FirePhase.Complete; } }
        public bool EvacuationOrdered { get { return Phase == FirePhase.Evacuation; } }
        public float FireX { get { return Layout.AptX(FireApt); } }
        public float FireZ { get { return FireInCorridor ? Layout.CorridorMid : Layout.AptZ(FireApt); } }
        public float CorridorRadius { get { return 2f + 5f * SmokeLevel; } }
        public bool HazardActive
        {
            get { return IsActive && Phase >= FirePhase.FireStarted && (SmokeLevel > 0.25f || FireIntensity > 0.15f); }
        }

        public void Configure(int floor, int apt, bool corridor)
        {
            FireFloor = Mathf.Clamp(floor, 1, Layout.Floors - 2);
            FireApt = Mathf.Clamp(apt, 0, 7);
            FireInCorridor = corridor;
        }

        /// <summary>Back to the briefing state, keeping the configured location.</summary>
        public void Reset()
        {
            Phase = FirePhase.Briefing;
            Elapsed = 0f; SinceIgnition = 0f;
            FireIntensity = 0f; SmokeLevel = 0f;
            AlarmOn = false; SprinklersActive = false; TimedOut = false;
            Evacuated = 0; ExposureSeconds = 0f; PlayerExposureSeconds = 0f;
            exposed.Clear();
        }

        public void Begin(int totalResidents)
        {
            Reset();
            TotalResidents = Math.Max(0, totalResidents);
            Phase = FirePhase.Normal;
        }

        public void Tick(float dt)
        {
            if (!IsActive || dt <= 0f) return;
            Elapsed += dt;

            if (Phase == FirePhase.Normal)
            {
                if (Elapsed >= NormalDuration)
                {
                    Phase = FirePhase.FireStarted;
                    AlarmOn = true;
                    SinceIgnition = 0f;
                }
            }
            else
            {
                SinceIgnition += dt;
                if (!SprinklersActive) FireIntensity = Mathf.MoveTowards(FireIntensity, 1f, dt / 8f);
                else FireIntensity = Mathf.MoveTowards(FireIntensity, 0.08f, dt / 18f);

                if (FireIntensity > 0.3f) SmokeLevel = Mathf.MoveTowards(SmokeLevel, 1f, dt / 12f);
                else SmokeLevel = Mathf.MoveTowards(SmokeLevel, 0f, dt / 150f);

                if (Phase == FirePhase.FireStarted && SinceIgnition >= SprinklerDelay)
                {
                    Phase = FirePhase.Sprinklers;
                    SprinklersActive = true;
                }
                if (Phase == FirePhase.Sprinklers && SinceIgnition >= SprinklerDelay + 3f)
                    Phase = FirePhase.Evacuation;
            }

            if (Phase != FirePhase.Complete && Elapsed >= TimeLimit) Finish(true);
        }

        public void ReportEvacuated()
        {
            if (!IsActive) return;
            Evacuated++;
            if (TotalResidents > 0 && Evacuated >= TotalResidents) Finish(false);
        }

        public void Finish(bool timedOut)
        {
            if (Phase == FirePhase.Complete) return;
            if (Phase == FirePhase.Briefing) return;
            Phase = FirePhase.Complete;
            TimedOut = timedOut;
        }

        public void AddResidentExposure(int residentId, float dt)
        {
            if (!IsActive) return;
            ExposureSeconds += dt;
            exposed.Add(residentId);
        }

        public void AddPlayerExposure(float dt) { if (IsActive) PlayerExposureSeconds += dt; }

        static bool AptContains(int apt, float x, float z)
        {
            float x0 = Layout.AptCol(apt) * Layout.AptWidth;
            bool north = Layout.AptSide(apt) == 1;
            float z0 = north ? Layout.CorridorZ1 : 0f;
            float z1 = north ? Layout.Depth : Layout.CorridorZ0;
            return x >= x0 && x <= x0 + Layout.AptWidth && z >= z0 && z <= z1;
        }

        /// <summary>True if a point on the given floor of the main block is in a smoke / fire hazard zone.</summary>
        public bool IsHazard(int floor, float x, float z)
        {
            if (!HazardActive) return false;
            bool inCorridor = z >= Layout.CorridorZ0 - 0.2f && z <= Layout.CorridorZ1 + 0.2f && x >= 0f && x <= Layout.Length;
            if (floor == FireFloor)
            {
                if (!FireInCorridor && AptContains(FireApt, x, z)) return true;
                if (inCorridor && Math.Abs(x - FireX) <= CorridorRadius) return true;
            }
            else if (floor == FireFloor + 1)
            {
                if (inCorridor && Math.Abs(x - FireX) <= CorridorRadius * 0.4f) return true;
            }
            return false;
        }

        /// <summary>True if the stair core (0 west, 1 east) is smoke-logged at that height.</summary>
        public bool IsCoreSmoky(int core)
        {
            return HazardActive && SmokeLevel >= 0.5f && Math.Abs(FireX - Layout.CoreX(core)) <= 9f;
        }

        public bool IsHazardAt(Vector3 p)
        {
            if (!HazardActive) return false;
            if (p.x < -0.1f || p.x > Layout.Length + 0.1f)
            {
                int core = p.x < 0f ? 0 : 1;
                float lo = Layout.FloorY(FireFloor) - 0.3f;
                float hi = Layout.FloorY(FireFloor + 2);
                return IsCoreSmoky(core) && p.y >= lo && p.y <= hi;
            }
            return IsHazard(Layout.FloorAt(p.y), p.x, p.z);
        }

        /// <summary>Cheapest stair for a resident, avoiding the (projected) hazard where possible.</summary>
        public RouteChoice ChooseRoute(int floor, int apt)
        {
            float xd = Layout.AptX(apt);
            RouteChoice best = null;
            for (int core = 0; core < 2; core++)
            {
                float cx = Layout.CoreX(core);
                float lo = Math.Min(xd, cx), hi = Math.Max(xd, cx);
                float cost = Math.Abs(xd - cx);
                bool pen = false;
                if (floor == FireFloor && hi >= FireX - 5f && lo <= FireX + 5f) { cost += 100f; pen = true; }
                if (floor >= FireFloor && Math.Abs(FireX - cx) <= 9f) { cost += 40f; pen = true; }
                if (best == null || cost < best.Cost)
                    best = new RouteChoice { Core = core, Cost = cost, Penalized = pen };
            }
            return best;
        }

        public string RouteSafetyLabel
        {
            get
            {
                if (TotalResidents == 0) return "n/a";
                float avg = ExposureSeconds / TotalResidents;
                if (ExposureSeconds < 1f) return "Good - no hazard exposure";
                if (avg < 5f) return "Moderate - brief hazard exposure";
                return "Poor - heavy hazard exposure";
            }
        }

        public TrainingRecord BuildRecord()
        {
            return new TrainingRecord
            {
                scenario = "Fire",
                timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm"),
                durationSeconds = Elapsed,
                completed = Phase == FirePhase.Complete && Evacuated >= TotalResidents && TotalResidents > 0,
                status = Evacuated >= TotalResidents && TotalResidents > 0 ? "All residents evacuated"
                         : (TimedOut ? "Time limit reached" : "Ended early"),
                totalResidents = TotalResidents,
                evacuated = Evacuated,
                remaining = Remaining,
                exposureSeconds = ExposureSeconds,
                exposedResidents = ExposedResidents,
                routeSafety = RouteSafetyLabel
            };
        }
    }
}
