using System;
using UnityEngine;

namespace UrbanSim
{
    public enum LeakPhase { Initial = 0, Reported = 1, Located = 2, Repaired = 3, Failed = 4 }
    public enum InspectOutcome { NotReady, Clue, Wrong, SourceFound, AlreadyLocated }
    public enum RepairOutcome { NotLocated, NeedPlumber, NeedValveClosed, Repaired, AlreadyRepaired }

    /// <summary>Pure state machine for the water-leak scenario.</summary>
    public class LeakModel
    {
        public const string PointClue = "puddle";
        public const string PointSink = "sink";
        public const string PointHeater = "heater";
        public const string PointPanel = "panel";

        public int Floor = 9;
        public int Apt = 2;
        public float TimeLimit = 600f;        // after the report

        public LeakPhase Phase = LeakPhase.Initial;
        public bool PlumberOnSite;
        public bool ValveClosed;
        public float SinceReport;
        public float ReportedAt = -1f, LocatedAt = -1f, RepairedAt = -1f;
        public float SpilledLitres;
        public int WrongInspections;
        public bool ClueFound;

        public bool IsActive { get { return Phase == LeakPhase.Reported || Phase == LeakPhase.Located; } }
        public bool Located { get { return Phase == LeakPhase.Located || (Phase == LeakPhase.Repaired); } }
        public bool Stopped { get { return Phase == LeakPhase.Repaired; } }
        public bool Finished { get { return Phase == LeakPhase.Repaired || Phase == LeakPhase.Failed; } }

        /// <summary>Relative leak flow: 1 full, 0.25 valve closed, 0 repaired.</summary>
        public float LeakRate
        {
            get
            {
                if (Phase == LeakPhase.Repaired) return 0f;
                if (Phase == LeakPhase.Initial) return 1f;      // the leak exists before it is reported
                return ValveClosed ? 0.25f : 1f;
            }
        }

        public string StatusText
        {
            get
            {
                switch (Phase)
                {
                    case LeakPhase.Initial: return "No report filed";
                    case LeakPhase.Reported: return PlumberOnSite ? "Reported - plumber on site, source not found" : "Reported - plumber en route";
                    case LeakPhase.Located: return ValveClosed ? "Source located - supply shut off" : "Source located - leak still active";
                    case LeakPhase.Repaired: return "Repaired";
                    default: return "Unresolved - time limit reached";
                }
            }
        }

        public void Reset()
        {
            Phase = LeakPhase.Initial; PlumberOnSite = false; ValveClosed = false;
            SinceReport = 0f; ReportedAt = LocatedAt = RepairedAt = -1f;
            SpilledLitres = 0f; WrongInspections = 0; ClueFound = false;
        }

        public bool Report()
        {
            if (Phase != LeakPhase.Initial) return false;
            Phase = LeakPhase.Reported;
            ReportedAt = 0f; SinceReport = 0f;
            return true;
        }

        public void PlumberArrived() { if (IsActive) PlumberOnSite = true; }

        public void Tick(float dt)
        {
            if (dt <= 0f || Finished) return;
            SpilledLitres += LeakRate * dt * 0.6f;
            if (IsActive)
            {
                SinceReport += dt;
                if (SinceReport >= TimeLimit) Phase = LeakPhase.Failed;
            }
        }

        public InspectOutcome Inspect(string point)
        {
            if (Phase == LeakPhase.Initial || Phase == LeakPhase.Failed) return InspectOutcome.NotReady;
            if (Phase == LeakPhase.Located || Phase == LeakPhase.Repaired) return InspectOutcome.AlreadyLocated;
            if (point == PointPanel)
            {
                Phase = LeakPhase.Located;
                LocatedAt = SinceReport;
                return InspectOutcome.SourceFound;
            }
            if (point == PointClue) { ClueFound = true; return InspectOutcome.Clue; }
            WrongInspections++;
            return InspectOutcome.Wrong;
        }

        public bool CloseValve()
        {
            if (Phase != LeakPhase.Located || ValveClosed) return false;
            ValveClosed = true;
            return true;
        }

        public RepairOutcome TryRepair()
        {
            if (Phase == LeakPhase.Repaired) return RepairOutcome.AlreadyRepaired;
            if (Phase != LeakPhase.Located) return RepairOutcome.NotLocated;
            if (!PlumberOnSite) return RepairOutcome.NeedPlumber;
            if (!ValveClosed) return RepairOutcome.NeedValveClosed;
            Phase = LeakPhase.Repaired;
            RepairedAt = SinceReport;
            return RepairOutcome.Repaired;
        }

        public void Abandon() { if (IsActive) Phase = LeakPhase.Failed; }

        public float TimeToInvestigate { get { return LocatedAt >= 0f ? LocatedAt - Mathf.Max(0f, ReportedAt) : -1f; } }
        public float TimeToRepair { get { return RepairedAt >= 0f && LocatedAt >= 0f ? RepairedAt - LocatedAt : -1f; } }

        public TrainingRecord BuildRecord()
        {
            return new TrainingRecord
            {
                scenario = "Leak",
                timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm"),
                durationSeconds = SinceReport,
                completed = Phase == LeakPhase.Repaired,
                status = StatusText,
                timeToInvestigate = TimeToInvestigate,
                timeToRepair = TimeToRepair,
                leakLocated = Located,
                leakStopped = Stopped,
                wrongInspections = WrongInspections
            };
        }
    }
}
